@extends('frontend.viewport')

@section('title', 'Product Details')

@section('css')
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" />
    <style>
        body {
            font-family: 'Ubuntu', sans-serif;
        }

        .productBox {
            float: left;
            width: 100%;
        }

        .productPageHeader {
            width: calc(100% - 20px);
            margin: 0 auto;
        }

        .productPageHeader .card {
            padding: 5px;
            display: block;
            float: left;
            width: 100%;
            margin-bottom: 10px;
        }

        .productPageHeader .card ul {
            padding: 0;
            margin: 0;
        }

        .productPageHeader .card ul li {
            float: left;
            list-style: none;
            padding: 0 2px;
            color: #007bff;
            font-weight: bold;
        }

        .productPageHeader .card ul li a {
            text-decoration: none;
            color: #007bff;
            transition: .5s ease-in-out;
        }

        .productPageHeader .card ul li a:hover {
            color: #1a1a2e;
            transition: .5s ease-in-out;
        }

        .links {
            float: left;
            width: calc(100% - 100px);
        }

        .share {
            float: right;
            width: 100px;
        }

        .share button {
            width: 100%;
            border-radius: 30px;
            border: none;
            background: #007bff;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
        }



        .product-section {
            padding: 40px 0;
        }

        .productBox .row {
            width: 100%;
            margin: 0;
            padding: 0;
        }

        .gallery-wrapper {
            display: flex;
            gap: 15px;
            align-items: flex-start;
            position: relative;
        }

        .thumbs-wrapper {
            position: relative;
            display: flex;
            flex-direction: column;
            gap: 0;
            width: 90px;
            overflow: hidden;
        }

        .thumbs {
            display: flex;
            flex-direction: column;
            gap: 10px;
            height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: #fff;
            width: auto;
            scrollbar-width: none;
            -ms-overflow-style: none;
            padding: 5px;
        }

        .thumbs::-webkit-scrollbar {
            display: none;
        }

        .thumbs img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border: 1px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
            background: #fff;
        }


        /* Main Image */
        .main-img-container {
            width: 100%;
            max-width: 400px;
            border: 1px solid #ddd;
            overflow: hidden;
            background: #fff;
            border-radius: 8px;
            position: relative;
        }

        .slider-single img {
            width: 100%;
            height: 420px;
            object-fit: cover;
            border-radius: 8px;
            cursor: zoom-in;
            user-select: none;
            transform: scale(1.0);
            transition: transform 0.3s ease;
        }


        .sliderNavBox {
            position: relative;
            border: 1px solid rgba(0, 0, 0, 0.175);
            border-radius: 5px;
            overflow: hidden;
        }

        .sliderNavBox .slider-nav-prev {
            width: 100%;
            border: none;
            z-index: 100;
            position: sticky;
        }

        .sliderNavBox .slider-nav-next {
            width: 100%;
            border: none;
            z-index: 100;
            position: sticky;
        }

        .slider-nav {
            overflow-y: scroll;
            width: 100px;
        }

        .slider-nav img {
            width: 85px;
            height: 85px;
            border-radius: 4px;
            border: 1px solid #000;
            padding: 0;
            float: left;
            overflow: hidden;
            object-fit: cover;
            margin: 1px;
        }

        .slider-nav .slick-slide {
            cursor: pointer;
            margin: 5px;
        }

        .slider-nav .slick-list {
            height: 368px !important;
            overflow: hidden;
            overflow-y: scroll;
            scrollbar-width: none;
        }

        .slider-single .slick-list {
            height: 420px !important;
        }

        .slick-slide.is-active img {
            border: 2px solid #6b4ff6;
            border-radius: 4px;
        }

        .slider-single .zoom {
            transform: scale(1.4);
            transform-origin: center center;
        }



        .product-info {
            border: 1px solid rgba(0, 0, 0, 0.175);
            border-radius: 5px;
            background: #fff;
            padding: 20px;
            margin-left: -12px;
        }

        /* Product details */
        .product-info h2 {
            font-size: 28px;
            font-weight: 600;
        }

        .rating {
            color: #ffa500;
            font-size: 16px;
            margin: 8px 0;
        }

        .price {
            font-size: 35px;
            font-weight: 700;
            color: #e53935;
            float: left;
            width: 100%;
            display: block;
        }

        .discount-ribbon {
            background: linear-gradient(135deg, #FF4B2B, #FF416C);
            color: white;
            padding: 5px 10px;
            font-size: 14px;
            font-weight: bold;
            margin: 10px 0;
            float: left;
            display: block;
            border-radius: 3px;
        }

        .stockUpdate {
            margin: 5px 0;
            float: left;
            width: 100%;
            font-weight: bold;
            color: #8181e0;
        }



        .qntt {
            width: 300px;
            border: 1px solid rgba(0, 0, 0, 0.175);
            float: left;
            display: block;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }

        .qntt button {
            width: 50px;
            float: left;
            height: 35px;
            border: 1px solid rgba(0, 0, 0, 0.175);
            background: #1a1a2e;
            color: #fff;
        }

        .qntt button:hover {
            color: yellow;
        }

        .qntt button:first-child {
            border-top-left-radius: 8px;
            border-bottom-left-radius: 8px;
        }

        .qntt button:last-child {
            border-top-right-radius: 8px;
            border-bottom-right-radius: 8px;
        }

        .qntt input {
            width: calc(100% - 100px);
            float: left;
            text-align: center;
            border: 3px solid #1a1a2e;
            height: 35px;
        }

        .qntt input:focus-visible {
            border: 3px solid #1a1a2e;
            outline: none;
        }



        .orderProcessBtn {
            width: 100%;
            float: left;
            display: block;
        }

        .orderProcessBtn button {
            background: #1a1a2e;
            color: #fff;
            padding: 12px 25px;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            margin-top: 10px;
            transition: 0.5s ease-in-out;
        }

        .orderProcessBtn button:last-child {
            margin-left: 10px;
            background: linear-gradient(135deg, #8686e7, #1a1a2e);
            transition: 0.5s linear;
        }

        .orderProcessBtn button:last-child:hover {
            background: linear-gradient(135deg, #8686e7, #8686e7);
            transition: 0.5s linear;
        }

        .orderProcessBtn button:hover {
            background: #4a4a7c;
            transition: 0.3s ease-in-out;
        }



        .fullDesc {
            margin-top: 15px;
            width: 100%;
        }

        .fullDesc p {
            margin-bottom: 0 !important;
        }

        .fullDesc .card {
            padding: 15px;
            overflow: hidden;
        }

        .fullDesc .nav {
            margin-bottom: 0px;
        }

        .review-container {
            display: flex;
            gap: 30px;
            margin: 20px auto;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            flex-wrap: wrap;
        }

        .review-content {
            flex: 1 1 60%;
            min-width: 300px;
            text-align: left;
        }

        /* Review boxes styling */
        .review-box {
            background: #fff;
            border: 1px solid #ddd;
            padding: 15px 20px;
            margin-bottom: 18px;
            border-radius: 8px;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.05);
        }

        .review-header {
            display: block;
            align-items: center;
            margin-bottom: 10px;
        }

        .review-header strong {
            font-size: 20px;
            color: #333;
        }

        .stars {
            color: #fbc02d;
            font-size: 18px;
            width: 100%;
            display: block;
            float: left;
            margin: 10px 0;
        }

        .date {
            font-size: 13px;
            color: #888;
            float: right;
        }

        .review-text {
            font-size: 16px;
            color: #555;
            line-height: 1.5;
        }

        /* Review form styling */
        .review-form {
            flex: 1 1 35%;
            min-width: 280px;
            background: #fafafa;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #ddd;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.03);
            box-sizing: border-box;
            margin-top: 0;
            /* reset margin for desktop */
        }

        /* Form elements */
        .review-form h3 {
            margin-bottom: 15px;
            color: #333;
        }

        .review-form label {
            font-weight: 600;
            margin-bottom: 6px;
            display: block;
            color: #444;
        }

        .review-form input[type="text"],
        .review-form select,
        .review-form textarea {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            font-family: inherit;
            resize: vertical;
        }

        .review-form button {
            background-color: #007bff;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease-in-out;
            width: 100%;
        }

        .review-form button:hover {
            background-color: #0056b3;
            transition: background-color 0.3s ease-in-out;
        }



        .productCardRow {
            width: 100%;
            overflow: hidden;
        }

        .productCard {
            width: calc(20% - 20px);
            float: left;
            background: #fff;
            border: 1px solid #e5e5e5;
            border-radius: 10px;
            padding: 15px;
            text-decoration: none;
            color: #000;
            transition: .3s linear;
            margin: 10px;
            overflow: hidden;
            position: relative;
            display: block;
        }

        .productCard:hover {
            box-shadow: 0 0 10px -4px #00000096;
            transition: .3s linear;
        }

        .productCard:hover.productCard img {
            transform: scale(1.05);
            transition: .3s linear;
        }

        .productCard .imgBox {
            width: 100%;
            height: 180px;
            overflow: hidden;
            transition: .3s linear;
        }

        .productCard img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 10px;
            transition: .3s linear;
        }

        .productCard h3 {
            font-size: 20px;
            color: #000;
            margin: 10px 0;
        }

        .productCard p {
            font-size: 14px;
            color: #666;
            margin-bottom: 0px;
        }

        .productCard .price {
            font-size: 20px;
            color: #000000;
            font-weight: bold;
            display: block;
        }

        .productCard b {
            font-weight: normal;
            font-size: 13px;
        }

        .productCard .sold {
            float: left;
            font-size: 16px;
        }

        .productCard .sold span {
            font-style: normal;
        }

        .productCard .rating {
            float: left;
            font-size: 14px;
            margin: 2px;
            font-style: italic;
        }

        .productCard b span {
            font-size: 15px;
            font-style: italic;
        }

        .discountRibbon {
            position: absolute;
            top: 20px;
            right: -40px;
            background-color: #ff4d4d;
            color: white;
            font-weight: bold;
            font-size: 12px;
            transform: rotate(45deg);
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
            z-index: 10;
            pointer-events: none;
            width: 130px;
            text-align: center;
            padding: 0;
        }

        #brand img {
            max-width: 200px;
        }





        @media only screen and (max-width: 1400px) {
            .product-section .col-md-5 {
                width: 40%;
            }

            .product-section .col-md-7 {
                width: calc(60% - 10px);
                margin: 0;
            }

            .slider-nav img {
                width: 65px;
                height: 65px;
            }
        }


        @media only screen and (max-width: 1200px) {
            .product-section {
                padding: 40px 10px;
            }
        }


        @media only screen and (max-width: 1050px) {
            .product-section .col-md-5 {
                width: 50%;
            }

            .product-section .col-md-7 {
                width: calc(50% - 10px);
            }

            .product-info h2 {
                font-size: 22px;
            }

            .slider-single .slick-list {
                height: 380px !important;
            }

            .slider-single img {
                height: 380px;
            }

            .slider-nav .slick-list {
                height: 328px !important;
            }

            .price {
                font-size: 30px;
            }

            .orderProcessBtn button {
                padding: 8px 25px;
            }

            .productCard {
                width: calc(25% - 20px);
            }

        }


        @media only screen and (max-width: 950px) {
            .product-section .col-md-5 {
                width: 45%;
            }

            .product-section .col-md-7 {
                width: calc(55% - 10px);
            }

            .product-info h2 {
                font-size: 20px;
            }

            .slider-single .slick-list {
                height: 350px !important;
            }

            .slider-single img {
                height: 350px;
            }

            .slider-nav .slick-list {
                height: 298px !important;
            }

            .price {
                font-size: 24px;
            }

            .qntt {
                margin: 6px 0;
            }

            .slider-nav img {
                width: 60px;
                height: 60px;
            }

        }




        @media only screen and (max-width: 900px) {


            .productCard {
                width: calc(33% - 20px);
            }


        }


        @media only screen and (max-width: 800px) {

            .product-section .col-md-5 {
                width: 100%;
            }

            .product-section .col-md-7 {
                width: calc(100% - 24px) !important;
                margin: 0 12px;
                margin-top: 15px;
            }


            .main-img-container {
                width: 100%;
                max-width: 670px;
                border: 1px solid #ddd;
                overflow: hidden;
                background: #fff;
                border-radius: 8px;
                position: relative;
            }

            .slider-single .slick-list {
                height: 500px !important;
            }

            .slider-single img {
                height: 500px;
                object-fit: contain;
            }

            .slider-nav .slick-list {
                height: 448px !important;
            }

            .slider-nav img {
                width: 70px;
                height: 70px;
            }

            .product-info h2 {
                font-size: 25px;
            }

        }


        @media only screen and (max-width: 650px) {

            .productCard .imgBox {
                height: 140px;
            }

            .productCard img {
                height: 140px;
            }
        }

        @media only screen and (max-width: 600px) {

            .slider-single .slick-list {
                height: 400px !important;
            }

            .slider-single img {
                height: 400px;
                object-fit: contain;
            }

            .slider-nav .slick-list {
                height: 348px !important;
            }

            .slider-nav img {
                width: 65px;
                height: 65px;
            }

            .productCard {
                width: calc(50% - 20px);
            }

        }



        @media only screen and (max-width: 500px) {

            .product-section {
                padding: 40px 0px;
            }

            .slider-single .slick-list {
                height: 300px !important;
            }

            .slider-single img {
                height: 300px;
                object-fit: fill;
            }

            .slider-nav .slick-list {
                height: 248px !important;
            }

            .slider-nav img {
                width: 60px;
                height: 60px;
            }

        }


        @media only screen and (max-width: 450px) {

            .fullDesc .nav-link {
                font-size: 14px;
            }

            .orderProcessBtn button {
                padding: 8px 0;
                width: calc(50% - 10px);
                margin-right: 5px;
                float: left;
            }

            .orderProcessBtn button:last-child {
                margin-left: 5px;
                margin-right: 0;
                float: right;
            }

            .qntt {
                width: 100%;
                border-radius: 5px;
            }

            .qntt button:first-child {
                border-top-left-radius: 5px;
                border-bottom-left-radius: 5px;
            }

            .qntt button:last-child {
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
            }

        }

        @media only screen and (max-width: 401px) {
            .productCard {
                width: calc(100% - 20px);
            }

            .productCard .imgBox {
                height: 320px;
            }

            .productCard img {
                height: 320px;
                object-fit: cover;
            }

        }
    </style>
@endsection

@section('content')

    <div class="productBox">
        <div class="container product-section">

            <div class="productPageHeader">
                <div class="card">
                    <div class="links">
                        <ul>
                            <li>
                                <a href="/"><i class="fa-duotone fa-light fa-house"></i></a>
                            </li>
                            <li>/</li>
                            <li>
                                @php
                                    $cat = DB::table('categories')->where('id', $pdt->category_id)->first('name');
                                @endphp
                                <a href="">{{ $cat->name }}</a>
                            </li>
                            <li>/</li>
                            <li>
                                @php
                                    $cat = DB::table('sub_categories')
                                        ->where('id', $pdt->sub_category_id)
                                        ->first('name');
                                @endphp
                                <a href="">{{ $cat->name }}</a>
                            </li>
                            <li>/</li>
                            <li>
                                @php
                                    $cat = DB::table('child_categories')
                                        ->where('id', $pdt->child_category_id)
                                        ->first('name');
                                @endphp
                                <a href="">{{ $cat->name }}</a>
                            </li>
                        </ul>
                    </div>
                    <div class="share">
                        <button>
                            Share
                            <i class="fa-duotone fa-light fa-share"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- Product Gallery -->
                <div class="col-md-5">
                    <div class="gallery-wrapper">
                        <div class="slider sliderNavBox">
                            <button class="slider-nav-prev">
                                <i class="fa-solid fa-angle-up"></i>
                            </button>
                            <div class="slider-nav">
                                @foreach ($pdtImg as $imgs)
                                    <div>
                                        <img src="{{ asset($imgs->image) }}" data-large="{{ asset($imgs->image) }}"
                                            class="" alt="Thumb 1">
                                    </div>
                                @endforeach
                            </div>
                            <button class="slider-nav-next">
                                <i class="fa-solid fa-angle-down"></i>
                            </button>
                        </div>
                        <!-- Main Image -->
                        <div class="main-img-container">
                            <div class="slider slider-single">
                                @foreach ($pdtImg as $imgs)
                                    <div>
                                        <img src="{{ asset($imgs->image) }}" data-large="{{ asset($imgs->image) }}"
                                            class="" alt="Item">
                                    </div>
                                @endforeach
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Product Details -->
                <div class="col-md-7 product-info">
                    <h2>{{ $pdt->name }}</h2>
                    <div class="rating">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star-half-stroke"></i>
                        <i class="fa-regular fa-star"></i> (120 Reviews)
                    </div>
                    <div class="price">
                        @if (!empty($pdt->discount_price))
                            @php
                                $discountAmount = ($pdt->sale_price * $pdt->discount_price) / 100;
                                $finalPrice = $pdt->sale_price - $discountAmount;
                            @endphp

                            <div>
                                <div>
                                    <del style="font-size: 18px;">৳{{ number_format($pdt->sale_price) }}</del>
                                    <span
                                        style="font-weight: bold; color: #E53935;">৳{{ number_format($finalPrice) }}</span>
                                </div>
                            </div>

                            <span class="discount-ribbon">{{ number_format($pdt->discount_price) }}% OFF</span>
                        @else
                            <span>৳{{ number_format($pdt->sale_price) }}</span>
                        @endif
                    </div>

                    <div class="stockUpdate">
                        <span>
                            <i class="fa-duotone fa-thin fa-boxes-stacked"></i>
                            {{ $pdt->total_stock }} products in stock
                        </span>
                    </div>

                    <div class="qntt">
                        <button onclick="qnttdown()"><i class="fa-solid fa-minus"></i></button>
                        <input type="text" value="1" readonly id="qnttVal">
                        <button onclick="qnttup()"><i class="fa-solid fa-plus"></i></button>
                    </div>

                    <div class="orderProcessBtn">
                        <button><i class="fa-solid fa-cart-shopping"></i> Add to Cart</button>
                        <button><i class="fa-regular fa-bag-shopping"></i> Buy Now </button>
                    </div>

                </div>
            </div>

            <div class="row fullDesc">

                <div class="col-12 mt-3">
                    <div class="card">
                        <p>
                            {{ $pdt->short_description }}
                        </p>
                    </div>
                </div>


                <div class="col-12 mt-3">
                    <div class="card">
                        <!-- Tabs Navigation -->
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home"
                                    type="button" role="tab">
                                    Description
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="brand-tab" data-bs-toggle="tab" data-bs-target="#brand"
                                    type="button" role="tab">
                                    Brand
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile"
                                    type="button" role="tab">
                                    Reviews
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact"
                                    type="button" role="tab">
                                    Policy
                                </button>
                            </li>
                        </ul>

                        <!-- Tabs Content -->
                        <div class="tab-content mt-3" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel">
                                {!! $pdt->description !!}
                            </div>
                            <div class="tab-pane fade" id="brand" role="tabpanel">
                                <h4>Brand Information:</h4>
                                @php
                                    $brand = DB::table('brands')->where('id', $pdt->brand_id)->first();
                                @endphp
                                @if (!empty($brand->image))
                                    <img src="{{ asset($brand->image) }}" alt="Brand">
                                    <p>
                                        {{ $brand->description }}
                                    </p>
                                    <a href="{{ $brand->website }}" target="_blank" class="btn btn-primary mt-3">Visit Brand
                                        Site</a>
                                @endif
                                
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel">
                                <h3>Customer Reviews</h3>
                                <div class="review-container">
                                    <div class="review-content">
                                        <div class="review-box">
                                            <div class="review-header">
                                                <strong>Rakib Hossain</strong>
                                                <span class="date">July 28, 2025</span>
                                                <span class="stars">⭐⭐⭐⭐⭐</span>
                                            </div>
                                            <p class="review-text">
                                                The fabric quality is top-notch and fits me perfectly. Highly recommended!
                                                Will definitely purchase again.
                                            </p>
                                        </div>


                                    </div>

                                    <div class="review-form">
                                        <h3>Write a Review</h3>
                                        <form id="reviewForm">
                                            <label for="rating">Rating:</label>
                                            <select id="rating" name="rating" required>
                                                <option value="">Select rating</option>
                                                <option value="5">⭐⭐⭐⭐⭐ (5)</option>
                                                <option value="4">⭐⭐⭐⭐ (4)</option>
                                                <option value="3">⭐⭐⭐ (3)</option>
                                                <option value="2">⭐⭐ (2)</option>
                                                <option value="1">⭐ (1)</option>
                                            </select>

                                            <label for="review">Review:</label>
                                            <textarea id="review" name="review" rows="5" placeholder="Write your review here..." required></textarea>

                                            <button type="submit">Submit Review</button>
                                        </form>
                                    </div>
                                </div>

                            </div>
                            <div class="tab-pane fade" id="contact" role="tabpanel">
                                <h4>Our Policy </h4>
                                <p>This is the content of the Contact tab.</p>
                            </div>
                        </div>


                    </div>
                </div>
            </div>


        </div>
    </div>

    <div class="relatedProducts">
        <div class="container">
            <h3>Related Products</h3>

            <div class="productBox">
                <div class="productCardRow">
                    @foreach ($relatedProducts as $product)
                        <a href="{{ url('/product/' . $product->slug) }}" class="productCard">
                            {{-- Ribbon style Discount Badge --}}
                            @if ($product->discount_price)
                                @php
                                    $discountPercent = number_format($product->discount_price, 0);
                                @endphp
                                <span class="discountRibbon">
                                    -{{ $discountPercent }}%
                                </span>
                            @endif

                            <div class="imgBox">
                                <img src="{{ asset($product->feature_image ?? 'images/default.png') }}"
                                    alt="{{ $product->name }}">
                            </div>
                            <h3>{{ Str::limit($product->name, 35, '...') }}</h3>

                            {{-- Short description limit 100 chars --}}
                            <p>{{ Str::limit($product->short_description, 50, '...') }}</p>

                            {{-- Price Section --}}
                            <span class="price">
                                @if ($product->discount_price)
                                    @php
                                        $discountAmount = ($product->sale_price * $product->discount_price) / 100;
                                        $finalPrice = $product->sale_price - $discountAmount;
                                    @endphp
                                    <del style="font-size: 12px;">৳{{ number_format($product->sale_price, 2) }}</del>
                                    ৳{{ number_format($finalPrice, 2) }}
                                @else
                                    ৳{{ number_format($product->sale_price, 2) }}
                                @endif

                            </span>

                            <b>
                                <div class="sold">
                                    {{ $product->total_stock ?? 0 }} Sold <span>|</span>
                                </div>
                                <span class="rating">
                                    @for ($i = 1; $i <= 5; $i++)
                                        @if ($product->rating >= $i)
                                            <i class="fa-solid fa-star"></i>
                                        @elseif($product->rating >= $i - 0.5)
                                            <i class="fa-solid fa-star-half-alt"></i>
                                        @else
                                            <i class="fa-regular fa-star"></i>
                                        @endif
                                    @endfor
                                </span>
                                <span>({{ round($product->rating, 1) }})</span>
                            </b>
                        </a>
                    @endforeach
                </div>
            </div>

        </div>
    </div>
@endsection

@section('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>


    <script>
        $('.slider-single').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            fade: true,
            adaptiveHeight: true,
            infinite: true,
            useTransform: true,
            speed: 1000,
            autoplay: true,
            autoplaySpeed: 1000,
            cssEase: 'cubic-bezier(0.77, 0, 0.18, 1)',
            prevArrow: $('.slider-nav-prev'),
            nextArrow: $('.slider-nav-next')
        });
        $('.slider-single').on('afterChange', function(e, s, c) {
            $('.slider-nav').slick('slickGoTo', c);
            var n = '.slider-nav .slick-slide[data-slick-index="' + c + '"]';
            $('.slider-nav .slick-slide.is-active').removeClass('is-active');
            $(n).addClass('is-active')
        });
        $('.slider-nav').on('init', function(e, s) {
            $('.slider-nav .slick-slide.slick-current').addClass('is-active')
        }).slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: false,
            focusOnSelect: true,
            vertical: true,
            infinite: true,
            arrows: false,
            cssEase: 'cubic-bezier(0.77, 0, 0.18, 1)',
            prevArrow: $('.slider-nav-prev'),
            nextArrow: $('.slider-nav-next')
        });
        $('.slider-nav').on('click', '.slick-slide', function(e) {
            e.preventDefault();
            var s = $(this).data('slick-index');
            $('.slider-single').slick('slickGoTo', s)
        });
        $('.slider-single').on('mousemove', '.slick-active img', function(e) {
            var s = $(this),
                o = s.offset(),
                l = e.pageX - o.left,
                a = e.pageY - o.top,
                r = l / s.width() * 100,
                t = a / s.height() * 100;
            r = Math.min(Math.max(r, 0), 100), t = Math.min(Math.max(t, 0), 100), s.addClass('zoom'), s.css(
                'transform-origin', r + '% ' + t + '%'), $('.slider-single').slick('slickPause')
        });
        $('.slider-single').on('mouseleave', '.slick-active img', function() {
            $(this).removeClass('zoom');
            $('.slider-single').slick('slickPlay')
        });
        var qnttMin = 1,
            qnttMax = {{ $pdt->total_stock }};

        function qnttup() {
            var e = $('#qnttVal').val();
            if (e < qnttMax) e++;
            $('#qnttVal').val(e)
        }

        function qnttdown() {
            var e = $('#qnttVal').val();
            if (e > qnttMin) e--;
            $('#qnttVal').val(e)
        }

        function equalizeHeightsByBox() {
            $('.productBox').each(function() {
                var e = 0,
                    t = $(this).find('.productCard');
                t.css('height', 'auto'), t.each(function() {
                    e = Math.max(e, $(this).height())
                }), t.height(e)
            })
        }
        $(document).ready(equalizeHeightsByBox), $(window).resize(equalizeHeightsByBox);
    </script>
@endsection
