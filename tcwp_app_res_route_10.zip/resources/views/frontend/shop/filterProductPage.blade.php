@foreach ($products as $product)
    <a href="{{ url('/product/' . $product->slug) }}" class="productCard">
        {{-- Ribbon style Discount Badge --}}
        @if ($product->discount_price)
            @php
                $discountPercent = number_format($product->discount_price, 0);
            @endphp
            <span class="discountRibbon">
                -{{ $discountPercent }}%
            </span>
        @endif

        <div class="imgBox">
            <img src="{{ asset($product->feature_image ?? 'images/default.png') }}" alt="{{ $product->name }}">
        </div>
        <h3>{{ Str::limit($product->name, 35, '...') }}</h3>

        {{-- Short description limit 100 chars --}}
        <p>{{ Str::limit($product->short_description ?? $product->description, 50, '...') }}</p>

        {{-- Price Section --}}
        <span class="price">
            @if ($product->discount_price)
                @php
                    $discountAmount = ($product->sale_price * $product->discount_price) / 100;
                    $finalPrice = $product->sale_price - $discountAmount;
                @endphp
                <del style="font-size: 12px;">৳{{ number_format($product->sale_price, 2) }}</del>
                ৳{{ number_format($finalPrice, 2) }}
            @else
                ৳{{ number_format($product->sale_price, 2) }}
            @endif
        </span>

        <b>
            <div class="sold">
                {{ $product->total_stock ?? 0 }} Sold <span>|</span>
            </div>
            <span class="rating">
                @for ($i = 1; $i <= 5; $i++)
                    @if ($product->rating >= $i)
                        <i class="fa-solid fa-star"></i>
                    @elseif($product->rating >= $i - 0.5)
                        <i class="fa-solid fa-star-half-alt"></i>
                    @else
                        <i class="fa-regular fa-star"></i>
                    @endif
                @endfor
            </span>
            <span>({{ round($product->rating, 1) }})</span>
        </b>
    </a>
@endforeach
