@extends('frontend.viewport')

@section('title', 'Shop')

@section('css')
    <style>
        .nav .menu ul li:nth-child(2) a {
            color: #0900ff;
        }

        .shopBox {
            float: left;
            width: 100%;
            margin-top: 40px;
        }

        .priceRange {
            margin-bottom: 20px;
        }

        .category {
            float: left;
            width: 20%;
            position: sticky;
            top: 90px;
            height: 100vh;
            overflow-y: auto;
        }

        .category .card {
            padding: 15px;
        }

        .productBox {
            height: max-content;
            float: left;
            width: calc(80% - 10px);
            margin-left: 10px;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid rgba(0, 0, 0, 0.175);
        }

        .price-filter {
            background: #fff;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
            width: 360px;
        }

        .price-filter h3 {
            margin-bottom: 20px;
            font-size: 20px;
            font-weight: 600;
            color: #333;
            text-align: center;
        }

        .range-inputs {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            gap: 10px;
        }

        .range-inputs input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 10px;
            font-size: 15px;
            text-align: center;
            transition: 0.3s;
        }

        .range-inputs input:focus {
            border-color: #4a90e2;
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.2);
            outline: none;
        }

        .range-input {
            position: relative;
            height: 20px;
        }

        .range-input input[type=range] {
            position: absolute;
            width: 100%;
            height: 5px;
            background: transparent;
            pointer-events: all;
            -webkit-appearance: none;
            z-index: 100;
        }

        input[type=range]::-webkit-slider-thumb {
            -webkit-appearance: none;
            height: 18px;
            width: 18px;
            border-radius: 50%;
            background: #4a90e2;
            border: 2px solid #fff;
            cursor: grab;
            position: relative;
            z-index: 2;
        }

        input[type=range]::-moz-range-thumb {
            height: 18px;
            width: 18px;
            border-radius: 50%;
            background: #4a90e2;
            border: 2px solid #fff;
            cursor: grab;
        }

        .slider {
            position: relative;
            height: 5px;
            background: #ddd;
            border-radius: 5px;
        }

        .slider .progress {
            position: absolute;
            height: 100%;
            background: linear-gradient(90deg, #4a90e2, #6cc1ff);
            border-radius: 5px;
            z-index: 1;
        }

        .categories h1 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            padding-bottom: 5px;
            border-bottom: 1px solid #ddd;
        }

        .categories h4 {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
            cursor: pointer;
        }

        .categories hr:last-child {
            display: none;
        }

        .categories ul {
            list-style: none;
            padding: 0;
            margin: 0;
            padding-left: 10px;
        }

        .categories ul li {
            font-size: 15px;
            font-weight: bold;
            margin: 10px 0;
            cursor: pointer;
        }

        .subCarItem {
            margin-left: 10px;
            cursor: pointer;
        }

        .childSubCat {
            margin-left: 10px;
        }

        .preloader {
            width: 100%;
            float: left;
        }

        .dots {
            margin: 0 auto;
            display: block;
            width: 80px;
        }

        .dots span {
            width: 15px;
            height: 15px;
            background: #0900ff;
            border-radius: 50%;
            animation: dots 0.6s ease-in-out infinite alternate;
            display: block;
            float: left;
            margin: 10px 5px;
        }

        .dots span:nth-child(2) {
            animation-delay: 0.2s;
        }

        .dots span:nth-child(3) {
            animation-delay: 0.4s;
        }

        .filterBtn {
            display: none;
        }

        @keyframes dots {
            from {
                transform: translateY(0);
            }

            to {
                transform: translateY(-20px);
            }
        }




        @media only screen and (max-width: 1400px) {
            .container {
                min-width: 100%;
            }
        }

        @media only screen and (max-width: 1250px) {
            .productCard {
                width: calc(33% - 20px) !important;
            }
        }

        @media only screen and (max-width: 1000px) {
            .category {
                margin-left: -215px;
                width: 200px;
            }

            .productBox {
                width: calc(100% - 0px);
                margin-left: 0;
            }

            .productCard {
                width: calc(25% - 20px) !important;
            }

            .productCard .sold {
                display: block;
                width: 100%;
            }

            .productCard img {
                height: 160px !important;
            }

            .productCard .imgBox {
                height: 160px !important;
            }

            .filterBtn {
                display: block;
                width: 40%;
                position: fixed;
                left: 50%;
                bottom: 20px;
                z-index: 1000;
                transform: translate(-50%);
                border: none;
                border-radius: 5px;
                background: #007bff;
                color: #fff;
                padding: 5px;
            }

            .ShowCategory {
                margin-left: 0px;
                position: fixed;
                z-index: 100000;
                height: 100vh;
                overflow: scroll;
                background: #fff;
                top: 0;
                left: 0;
                width: 300px;
                padding: 10px;
                transition: margin-left 0.3s ease-in-out;
            }
        }



        @media only screen and (max-width: 850px) {
            .productCard {
                width: calc(33% - 10px) !important;
                margin: 5px !important;
            }

            .productCard h3 {
                font-size: 17px !important;
            }

            .productCard p {
                font-size: 13px !important;
            }

            .productCard .price {
                font-size: 16px !important;
            }

            .productCard .sold {
                float: left;
                font-size: 14px !important;
            }

            .productBox {
                padding: 0 !important;
            }
        }


        @media only screen and (max-width: 710px) {
            .filterBtn {
                bottom: 70px;
            }
        }

        @media only screen and (max-width: 600px) {
            .productCard {
                width: calc(50% - 10px) !important;
            }

            .productCard p {
                display: none !important;
            }
        }


        @media only screen and (max-width: 400px) {

            .productCard {
                width: calc(100% - 10px) !important;
            }

            .productCard .imgBox {
                height: 250px !important;
            }

            .productCard .imgBox img {
                height: 250px !important;
            }

        }
    </style>
@endsection

@section('content')
    <div class="shopBox">
        <div class="container">
            <button class="filterBtn">
                <i class="fa-solid fa-filter"></i>
                <span>Filter</span>
            </button>
            <div class="category">
                <div class="priceRange">
                    <div class="card">
                        <h3>Price Range</h3>
                        <div class="range-inputs">
                            <input type="text" id="min-price" value="500">
                            <input type="text" id="max-price" value="1,00,000">
                        </div>

                        <div class="range-input">
                            <input type="range" id="range-min" min="100" max="100000" value="500"
                                step="500">
                            <input type="range" id="range-max" min="100" max="100000" value="100000"
                                step="500">
                            <div class="slider">
                                <div class="progress"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="categories">
                    <div class="card">
                        <h1>Categories</h1>
                        @foreach ($categories as $category)
                            @php
                                $subCats = $subcategories->where('category_id', $category->id);
                            @endphp

                            @if ($subCats->count() > 0)
                                <h4 onclick="catWiseFilter({{ $category->id }})">
                                    {{ $category->name }}
                                </h4>

                                <div class="subCatBox">
                                    @foreach ($subCats as $sub)
                                        <div class="subCarItem" onclick="subCatWiseFilter({{ $sub->id }})">
                                            {{ $sub->name }}
                                        </div>
                                        <div class="childSubCat">
                                            @php
                                                $childs = $childcategories->where('subcategory_id', $sub->id);
                                            @endphp

                                            @if ($childs->count())
                                                <ul class="child-categories">
                                                    @foreach ($childs as $child)
                                                        <li onclick="childCatWiseFilter({{ $child->id }})"> <i
                                                                class="fa-duotone fa-thin fa-circle-dot fa-beat-fade"></i>
                                                            {{ $child->name }}</li>
                                                    @endforeach
                                                </ul>
                                            @else
                                                <ul class="child-categories">
                                                    <li>
                                                        <i class="fa-solid fa-triangle-exclamation"></i>
                                                        No Child Categories
                                                    </li>
                                                </ul>
                                            @endif
                                        </div>
                                    @endforeach
                                </div>

                                <hr>
                            @endif
                        @endforeach
                    </div>
                </div>

            </div>

            <div class="productBox">
                <div class="preloader">
                    <div class="loader dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
                <div id="prodctContainer"></div>
            </div>
        </div>
    </div>


@endsection

@section('script')
    <script>
        const rangeMin = document.getElementById("range-min"),
            rangeMax = document.getElementById("range-max"),
            minPrice = document.getElementById("min-price"),
            maxPrice = document.getElementById("max-price"),
            progress = document.querySelector(".progress"),
            sliderMaxValue = 1e5,
            minGap = 500;

        function updateSlider() {
            let e = parseInt(rangeMin.value),
                a = parseInt(rangeMax.value);
            progress.style.left = e / 1e5 * 100 + "%", progress.style.right = 100 - a / 1e5 * 100 + "%", minPrice.value = e
                .toLocaleString("en-IN"), maxPrice.value = a.toLocaleString("en-IN")
        }
        var GlobalMinPrice, GlobalMaxPrice, GlobalType, GlobalCategoryId;

        function catWiseFilter(e) {
            GlobalMinPrice = document.getElementById("min-price").value, GlobalMaxPrice = document.getElementById(
                "max-price").value, GlobalType = "category", GlobalCategoryId = e, filterProducts()
        }

        function subCatWiseFilter(e) {
            GlobalMinPrice = document.getElementById("min-price").value, GlobalMaxPrice = document.getElementById(
                "max-price").value, GlobalType = "subCategory", GlobalCategoryId = e, filterProducts()
        }

        function childCatWiseFilter(e) {
            GlobalMinPrice = document.getElementById("min-price").value, GlobalMaxPrice = document.getElementById(
                "max-price").value, GlobalType = "childCategory", GlobalCategoryId = e, filterProducts()
        }

        function filterProducts() {
            $(".preloader").show(), $.ajax({
                url: "/filterProducts",
                type: "Get",
                data: {
                    minPrice: GlobalMinPrice,
                    maxPrice: GlobalMaxPrice,
                    type: GlobalType,
                    id: GlobalCategoryId
                },
                success: function(e) {
                    $("#prodctContainer").html(e), $(".preloader").hide(), $("#loadedProduct").html("20")
                }
            })
        }

        function filterProductPagination(e) {
            $(".paginationBtn" + e).addClass("active").siblings().removeClass("active"), $(".paginationBtn" + e).attr(
                    "disabled", !0).siblings().attr("disabled", !1), $("#productPages").html(" "), $(".preloader").show(),
                $("html, body").scrollTop(0);
            var a = 20 * e,
                t = $("#maximumProduct").val();
            a > t && (a = t), $("#loadedProduct").html(a), $.ajax({
                url: "/filterProductPages",
                type: "Get",
                data: {
                    minPrice: GlobalMinPrice,
                    maxPrice: GlobalMaxPrice,
                    type: GlobalType,
                    id: GlobalCategoryId,
                    page: e
                },
                success: function(e) {
                    $("#productPages").html(e), $(".preloader").hide(), equalizeHeightsByBox()
                }
            })
        }

        function filterProductPaginationRandom(e) {
            $(".paginationBtn" + e).addClass("active").siblings().removeClass("active"), $(".paginationBtn" + e).attr(
                    "disabled", !0).siblings().attr("disabled", !1), $("#productPages").html(" "), $(".preloader").show(),
                $("html, body").scrollTop(0);
            var a = 20 * e,
                t = $("#maximumProduct").val();
            a > t && (a = t), $("#loadedProduct").html(a), $.ajax({
                url: "/filterPageRandomProductsPagination",
                type: "Get",
                data: {
                    page: e
                },
                success: function(e) {
                    $("#productPages").html(e), $(".preloader").hide(), equalizeHeightsByBox()
                }
            })
        }
        rangeMin.addEventListener("input", (() => {
            parseInt(rangeMax.value) - parseInt(rangeMin.value) <= 500 && (rangeMin.value = parseInt(rangeMax
                .value) - 500), updateSlider()
        })), rangeMax.addEventListener("input", (() => {
            parseInt(rangeMax.value) - parseInt(rangeMin.value) <= 500 && (rangeMax.value = parseInt(rangeMin
                .value) + 500), updateSlider()
        })), minPrice.addEventListener("change", (() => {
            let e = parseInt(minPrice.value.replace(/,/g, ""));
            e < parseInt(rangeMin.min) && (e = parseInt(rangeMin.min)), e > parseInt(rangeMax.value) - 500 && (
                e = parseInt(rangeMax.value) - 500), rangeMin.value = e, updateSlider()
        })), maxPrice.addEventListener("change", (() => {
            let e = parseInt(maxPrice.value.replace(/,/g, ""));
            e > parseInt(rangeMax.max) && (e = parseInt(rangeMax.max)), e < parseInt(rangeMin.value) + 500 && (
                e = parseInt(rangeMin.value) + 500), rangeMax.value = e, updateSlider()
        })), updateSlider(), $(document).ready((function() {
            $.ajax({
                url: "/filterPageRandomProducts",
                type: "Get",
                data: {
                    page: 1
                },
                success: function(e) {
                    $("#prodctContainer").html(e), $(".preloader").hide(), equalizeHeightsByBox(),
                        $("#loadedProduct").html("20")
                }
            })
        })), $(".priceRange").on("change", (function() {
            var e = parseInt($("#min-price").val().replace(/,/g, "")),
                a = parseInt($("#max-price").val().replace(/,/g, ""));
            $(".preloader").show(), $("#prodctContainer").html(" "), $.ajax({
                url: "/filterProductsByPrice",
                type: "Get",
                data: {
                    minPrice: e,
                    maxPrice: a
                },
                success: function(e) {
                    $("#prodctContainer").html(e), $(".preloader").hide(), $("#loadedProduct").html(
                        "20"), equalizeHeightsByBox()
                }
            })
        })), $(".filterBtn").on("click", (function() {
            $(".category").addClass("ShowCategory"), $(".sideMenuCover").show(), $("html, body").css({
                overflow: "hidden",
                height: "100%"
            })
        })), $(".sideMenuCover").on("click", (function() {
            $(".category").removeClass("ShowCategory"), $(this).hide(), $("html, body").css({
                overflow: "auto",
                height: "auto"
            })
        }));
    </script>
@endsection
