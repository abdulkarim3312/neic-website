<style>
    .productContainerBox {
        margin: 5px 0;
    }

    .productContainerBox .productItems {
        width: calc(33% - 20px);
        float: left;
        padding: 10px;
        border: 1px solid #ddd;
        margin: 10px;
        background-color: #f9f9f9;
        border-radius: 5px;
    }

    .pagination {
        display: block;
        float: left;
        width: 100%;
    }

    .pagination .active {
        background-color: #000000 !important;
        color: white !important;
    }

    .pagination {
        margin-top: 10px;
        border-top: 1px solid #ddd;
        padding: 0 10px;
    }

    .pagination h2 {
        display: block;
        font-size: 15px;
        margin-top: 10px;
        width: 100%;
    }

    .pagination button {
        margin: 5px;
        padding: 5px 12px;
        border-radius: 5px;
        border: none;
        background-color: #007bff;
        color: white;
        cursor: pointer;
        border-radius: 50px;
    }

    .productCard {
        width: calc(25% - 20px);
        float: left;
        background: #fff;
        border: 1px solid #e5e5e5;
        border-radius: 10px;
        padding: 15px;
        text-decoration: none;
        color: #000;
        transition: .3s linear;
        margin: 10px;
        overflow: hidden;
        position: relative;
        display: block;
    }

    .productCard:hover {
        box-shadow: 0 0 10px -4px #00000096;
        transition: .3s linear;
    }

    .productCard:hover.productCard img {
        transform: scale(1.05);
        transition: .3s linear;
    }

    .productCard .imgBox {
        width: 100%;
        height: 200px;
        overflow: hidden;
        transition: .3s linear;
        border-radius: 10px;
    }

    .productCard img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 10px;
        transition: .3s linear;
    }

    .productCard h3 {
        font-size: 20px;
        color: #000;
        margin: 10px 0;
    }

    .productCard p {
        font-size: 14px;
        color: #666;
        margin-bottom: 5px;
    }

    .productCard .price {
        font-size: 20px;
        color: #000000;
        font-weight: bold;
        display: block;
    }

    .productCard b {
        font-weight: normal;
        font-size: 13px;
    }

    .productCard .sold {
        float: left;
        font-size: 16px;
    }

    .productCard .sold span {
        font-style: normal;
    }

    .productCard .rating {
        float: left;
        font-size: 14px;
        margin: 2px;
        font-style: italic;
    }

    .productCard b span {
        font-size: 15px;
        font-style: italic;
    }



    .discountRibbon {
        position: absolute;
        top: 20px;
        right: -40px;
        background-color: #ff4d4d;
        color: white;
        font-weight: bold;
        font-size: 12px;
        transform: rotate(45deg);
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
        z-index: 10;
        pointer-events: none;
        width: 130px;
        text-align: center;
        padding: 0;
    }
</style>
<div class="productContainerBox">
    @if ($products->isEmpty())
        <div class="alert alert-warning">
            No products found.
        </div>
    @endif

    <div id="productPages">
        @foreach ($products as $product)
            <a href="{{ url('/product/' . $product->slug) }}" class="productCard">
                {{-- Ribbon style Discount Badge --}}
                @if ($product->discount_price)
                    @php
                        $discountPercent = number_format($product->discount_price, 0);
                    @endphp
                    <span class="discountRibbon">
                        -{{ $discountPercent }}%
                    </span>
                @endif

                <div class="imgBox">
                    <img src="{{ asset($product->feature_image ?? 'images/default.png') }}" alt="{{ $product->name }}">
                </div>
                <h3>{{ Str::limit($product->name, 35, '...') }}</h3>

                {{-- Short description limit 100 chars --}}
                <p>{{ Str::limit($product->short_description ?? $product->description, 50, '...') }}</p>

                {{-- Price Section --}}
                <span class="price">
                    @if ($product->discount_price)
                        @php
                            $discountAmount = ($product->sale_price * $product->discount_price) / 100;
                            $finalPrice = $product->sale_price - $discountAmount;
                        @endphp
                        <del style="font-size: 12px;">৳{{ number_format($product->sale_price, 2) }}</del>
                        ৳{{ number_format($finalPrice, 2) }}
                    @else
                        ৳{{ number_format($product->sale_price, 2) }}
                    @endif
                </span>

                <b>
                    <div class="sold">
                        {{ $product->total_stock ?? 0 }} Sold <span>|</span>
                    </div>
                    <span class="rating">
                        @for ($i = 1; $i <= 5; $i++)
                            @if ($product->rating >= $i)
                                <i class="fa-solid fa-star"></i>
                            @elseif($product->rating >= $i - 0.5)
                                <i class="fa-solid fa-star-half-alt"></i>
                            @else
                                <i class="fa-regular fa-star"></i>
                            @endif
                        @endfor
                    </span>
                    <span>({{ round($product->rating, 1) }})</span>
                </b>
            </a>
        @endforeach
    </div>

    @if ($productCount > 0)
        @php
            $take = 20; // Number of products per page
            $totalPages = ceil($productCount / $take);
        @endphp
        <div class="pagination">
            <input type="hidden" id="maximumProduct" value="{{ $productCount }}">
            <h2> Showing <b><span id="loadedProduct"></span></b> Out Of <b>{{ $productCount }}</b></h2>
            @for ($i = 1; $i <= $totalPages; $i++)
                <button type="button" class="paginationBtn{{ $i }}"
                    onclick="filterProductPagination({{ $i }})">{{ $i }}</button>
            @endfor
        </div>
    @endif
</div>

<script>
    $('.paginationBtn1').addClass('active');
    $('.paginationBtn1').attr('disabled', true);

    function equalizeHeightsByBox() {
        $('.productBox').each(function() {
            var maxHeight = 0;
            var cards = $(this).find('.productCard');

            // Reset height
            cards.css('height', 'auto');
            cards.each(function() {
                if ($(this).height() > maxHeight) {
                    maxHeight = $(this).height();
                }
            });

            cards.height(maxHeight);
        });
    }

    $(document).ready(equalizeHeightsByBox);
    $(window).resize(equalizeHeightsByBox);
</script>
