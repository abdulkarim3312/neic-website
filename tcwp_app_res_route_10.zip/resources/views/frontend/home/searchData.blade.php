@foreach ($results as $res)
    d
@endforeach
