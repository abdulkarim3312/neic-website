@extends('frontend.viewport')

@section('title', 'Home')

@section('css')
    <link rel="stylesheet" href="{{ asset('asset/css/home.css') }}">
@endsection

@section('content')

    <div class="container">
        <div class="heroarea">
            <div class="slideBox">
                @foreach ($banners as $bnr)
                    <div class="slide">
                        <img src="{{ asset($bnr->image) }}" alt="Slider Image">
                    </div>
                @endforeach
            </div>
            <div class="CampaignBox">
                <h3>Quick View</h3>

                <a href="">
                    <i class="fa-duotone fa-thin fa-location-smile"></i>
                    <span>Tracking</span>
                </a>

                <a href="">
                    <i class="fa-duotone fa-solid fa-gift-card"></i>
                    <span>Gift Box</span>
                </a>

                <a href="">
                    <i class="fa-duotone fa-light fa-ticket-perforated"></i>
                    <span>Voucher</span>
                </a>

                <a href="">
                    <i class="fa-duotone fa-light fa-bolt-lightning"></i>
                    <span>Flash Sale</span>
                </a>

                <a href="">
                    <i class="fa-duotone fa-solid fa-percent"></i>
                    <span>Discount</span>
                </a>

            </div>
        </div>

        <div class="categoris">

            @foreach ($categories as $index => $item)
                @if (count($categories) > 5)
                    @if ($index < 4)
                        <a href="/" class="categoryBox">
                            <img src="{{ asset($item->image) }}" alt="Category Image">
                            <span>{{ $item->name }}</span>
                        </a>
                    @endif
                @else
                    <a href="/" class="categoryBox">
                        <img src="{{ asset($item->image) }}" alt="Category Image">
                        <span>{{ $item->name }}</span>
                    </a>
                @endif
            @endforeach

            @if (count($categories) > 5)
                <a href="/all-categories" class="categoryBox static">
                    <img src="{{ asset('asset/img/more-category.png') }}" alt="">
                    <span>More ({{ count($categories) - 4 }})</span>
                </a>
            @endif

        </div>





        <div class="productBox">
            <div class="productBoxHeader">
                <h2>Latest Products</h2>
                <a href="{{ url('/products') }}">View All</a>
            </div>
            <div class="productCardRow">
                @foreach ($latestProducts as $product)
                    <a href="{{ url('/product/' . $product->slug) }}" class="productCard">
                        {{-- Ribbon style Discount Badge --}}
                        @if ($product->discount_price)
                            @php
                                $discountPercent = number_format($product->discount_price, 0);
                            @endphp
                            <span class="discountRibbon">
                                -{{ $discountPercent }}%
                            </span>
                        @endif

                        <div class="imgBox">
                            <img src="{{ asset($product->feature_image ?? 'images/default.png') }}"
                                alt="{{ $product->name }}">
                        </div>
                        <h3>{{ Str::limit($product->name, 35, '...') }}</h3>

                        {{-- Short description limit 100 chars --}}
                        <p>{{ Str::limit($product->short_description, 50, '...') }}</p>

                        {{-- Price Section --}}
                        <span class="price">
                            @if ($product->discount_price)
                                @php
                                    $discountAmount = ($product->sale_price * $product->discount_price) / 100;
                                    $finalPrice = $product->sale_price - $discountAmount;
                                @endphp
                                <del style="font-size: 12px;">৳{{ number_format($product->sale_price, 2) }}</del>
                                ৳{{ number_format($finalPrice, 2) }}
                            @else
                                ৳{{ number_format($product->sale_price, 2) }}
                            @endif

                        </span>

                        <b>
                            <div class="sold">
                                {{ $product->total_stock ?? 0 }} Sold <span>|</span>
                            </div>
                            <span class="rating">
                                @for ($i = 1; $i <= 5; $i++)
                                    @if ($product->rating >= $i)
                                        <i class="fa-solid fa-star"></i>
                                    @elseif($product->rating >= $i - 0.5)
                                        <i class="fa-solid fa-star-half-alt"></i>
                                    @else
                                        <i class="fa-regular fa-star"></i>
                                    @endif
                                @endfor
                            </span>
                            <span>({{ round($product->rating, 1) }})</span>
                        </b>
                    </a>
                @endforeach
            </div>
        </div>



        @foreach ($pdt_subcat as $subcat)
            @if (isset($subcat->products) && count($subcat->products) > 0)
                <div class="productBox">
                    <div class="productBoxHeader">
                        <h2>{{ $subcat->name }}</h2>
                        <a href="{{ url('/subcategory/' . $subcat->id) }}">View All</a>
                    </div>

                    <div class="productCardRow">
                        @foreach ($subcat->products as $product)
                            <a href="{{ url('/product/' . $product->slug) }}" class="productCard">
                                {{-- Ribbon style Discount Badge --}}
                                @if ($product->discount_price)
                                    @php
                                        $discountPercent = number_format($product->discount_price, 0);
                                    @endphp
                                    <span class="discountRibbon">
                                        -{{ $discountPercent }}%
                                    </span>
                                @endif

                                <div class="imgBox">
                                    <img src="{{ asset($product->feature_image ?? 'images/default.png') }}"
                                        alt="{{ $product->name }}">
                                </div>
                                <h3>{{ Str::limit($product->name, 35, '...') }}</h3>

                                {{-- Short description limit 100 chars --}}
                                <p>{{ Str::limit($product->short_description ?? $product->description, 50, '...') }}</p>

                                {{-- Price Section --}}
                                <span class="price">
                                    @if ($product->discount_price)
                                        @php
                                            $discountAmount = ($product->sale_price * $product->discount_price) / 100;
                                            $finalPrice = $product->sale_price - $discountAmount;
                                        @endphp
                                        <del style="font-size: 12px;">৳{{ number_format($product->sale_price, 2) }}</del>
                                        ৳{{ number_format($finalPrice, 2) }}
                                    @else
                                        ৳{{ number_format($product->sale_price, 2) }}
                                    @endif
                                </span>

                                <b>
                                    <div class="sold">
                                        {{ $product->total_stock ?? 0 }} Sold <span>|</span>
                                    </div>
                                    <span class="rating">
                                        @for ($i = 1; $i <= 5; $i++)
                                            @if ($product->rating >= $i)
                                                <i class="fa-solid fa-star"></i>
                                            @elseif($product->rating >= $i - 0.5)
                                                <i class="fa-solid fa-star-half-alt"></i>
                                            @else
                                                <i class="fa-regular fa-star"></i>
                                            @endif
                                        @endfor
                                    </span>
                                    <span>({{ round($product->rating, 1) }})</span>
                                </b>
                            </a>
                        @endforeach
                    </div>
                </div>
            @endif
        @endforeach









    </div>




@endsection


@section('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.slideBox').slick({
                autoplay: true,
                autoplaySpeed: 3000,
                dots: true,
                arrows: false,
                fade: true,
                speed: 500,
                cssEase: 'linear'
            });
        });


        function equalizeHeightsByBox() {
            $('.productBox').each(function() {
                var maxHeight = 0;
                var cards = $(this).find('.productCard');

                // Reset height
                cards.css('height', 'auto');
                cards.each(function() {
                    if ($(this).height() > maxHeight) {
                        maxHeight = $(this).height();
                    }
                });

                cards.height(maxHeight);
            });
        }

        $(document).ready(equalizeHeightsByBox);
        $(window).resize(equalizeHeightsByBox);
    </script>
@endsection
