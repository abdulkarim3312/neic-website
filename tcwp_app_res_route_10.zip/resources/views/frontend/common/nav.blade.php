<style>
.dropdown-menu {
    padding: 4px 0; 
}
.dropdown-menu .dropdown-item {
    font-size: 14px;
    border-radius: 6px;
}
.dropdown-menu .dropdown-item:hover {
    background-color: #f5f5f5;
}
.form-floating .form-control {
    height: 50px;          
    font-size: 16px;       
    padding: 12px 10px;    
}

.form-floating > label {
    padding: 12px 10px;
    font-size: 14px;
}

.btn-success, .btn-primary {
    height: 50px;          
    font-size: 16px;
    font-weight: 500;
}

.form-check-input {
    width: 22px;
    height: 22px;
    margin-top: 4px;
}

.modal-body {
    padding: 40px 30px;
}

a {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

.text-danger {
    font-size: 13px;
}

.form-floating.mb-3 {
    margin-bottom: 20px;
}
</style>

@php
    $footer = DB::table('footers')->first();
@endphp
<div class="nav">
    <nav>
        <div class="container">
            <div class="logo">
                <a href="{{ url('/') }}">
                    @if (!empty($footer->logo_image))
                        <img src="{{ asset($footer->logo_image) }}" alt="Logo" />

                        @else

                        <img src="" alt="Logo" />

                    @endif
                </a>
            </div>
            <div class="menu">
                <ul>
                    <li>
                        <a href="{{ url('/') }}">
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('/shop') }}">
                            <span>Shop</span>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#searchModal">
                            <span>Search</span>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" id="cartShow">
                            <span>Cart</span>
                        </a>
                    </li>
                    <li class="menuBtn">
                        <a href="javascript:void(0)" id="sideMenuShow">
                            <i class="fa-solid fa-bars-staggered"></i>
                            <span> Menu</span>
                        </a>
                    </li>

                    <li>
                        @if (session()->has('customer'))
                            <div class="dropdown">
                                <a href="#" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <img src="https://cdn-icons-png.flaticon.com/512/5556/5556468.png"
                                        alt="User"
                                        style="width:40px; height:40px; border-radius:50%; border:2px solid #ddd; padding:2px;">
                                </a>

                                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0"
                                    aria-labelledby="userDropdown"
                                    style="min-width: 220px; border-radius:14px;">
                                    
                                    <li class="px-3 py-2 text-center border-bottom">
                                        <strong class="d-block text-uppercase" style="font-size:13px;">
                                            {{ strtoupper(session('customer.name')) }}
                                        </strong>
                                        <small class="text-muted" style="font-size:12px;">{{ session('customer.email') }}</small>
                                    </li>

                                    <li>
                                        <a class="dropdown-item d-flex align-items-center py-2 px-3"
                                        href="{{ route('customer.dashboard') }}">
                                            <i class="fa-solid fa-gauge-high me-2 text-primary"></i> Dashboard
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item d-flex align-items-center py-2 px-3"
                                        href="#">
                                            <i class="fa-solid fa-user"></i> Profile
                                        </a>
                                    </li>

                                    <li>
                                        <form action="{{ route('customer.logout') }}" method="POST">
                                            @csrf
                                            <button type="submit" class="dropdown-item d-flex align-items-center py-2 px-3 text-danger">
                                                <i class="bi bi-box-arrow-right me-2"></i> Logout
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        @else
                            <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#AuthForm">
                                <img src="{{ asset('lib/img/user.webp') }}" alt="User"
                                    style="width:40px; height:40px; border-radius:50%; border:2px solid #ddd; padding:2px;">
                            </a>
                        @endif

                    </li>
                </ul>
            </div>
        </div>
    </nav>
</div>


<div class="mobileNav">
    <ul>
        <li>
            <a href="/">
                <i class="fa-duotone fa-light fa-house"></i>
                <span>Home</span>
            </a>
        </li>
        <li>
            <a href="/shop">
                <i class="fa-duotone fa-regular fa-shop"></i>
                <span>Shop</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fa-duotone fa-light fa-cart-shopping"></i>
                <span>Cart</span>
            </a>
        </li>
        <li>
            <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#AuthForm">
                <i class="fa-duotone fa-light fa-user"></i>
                <span>Account</span>
            </a>
        </li>
    </ul>
</div>




<div class="sideMenuCover"></div>
<div class="sideMenu">
    <div class="header">
        <h3>Categories</h3>
        <button id="sideMenuClose">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
    <div class="accordion" id="accordionExample">
        @php
            $categories = DB::table('categories')->where('status', 1)->whereNull('parent_id')->get();
        @endphp
        <div class="accordion" id="categoryAccordion">
            @foreach ($categories as $category)
                @php
                    $subCategories = DB::table('sub_categories')
                        ->where('category_id', $category->id)
                        ->where('status', 1)
                        ->get();
                    $categoryId = 'category' . $category->id;
                @endphp
                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading{{ $categoryId }}">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapse{{ $categoryId }}" aria-expanded="false"
                            aria-controls="collapse{{ $categoryId }}">
                            @if ($category->image)
                                <img src="{{ asset($category->image) }}" alt="{{ $category->name }}"
                                    class="category-img">
                            @endif
                            {{ $category->name }}
                        </button>
                    </h2>
                    <div id="collapse{{ $categoryId }}" class="accordion-collapse collapse"
                        aria-labelledby="heading{{ $categoryId }}" data-bs-parent="#categoryAccordion">
                        <div class="accordion-body">
                            @if ($subCategories->count())
                                <ul class="sub-list">
                                    @foreach ($subCategories as $sub)
                                        @php
                                            $childCategories = DB::table('child_categories')
                                                ->where('subcategory_id', $sub->id)
                                                ->where('status', 1)
                                                ->get();
                                            $subId = 'subcategory' . $sub->id;
                                        @endphp
                                        <li>
                                            <a href="{{ url('/categories/' . $sub->slug) }}">
                                                <i class="fa-solid fa-angle-right"></i> {{ $sub->name }}
                                            </a>
                                            @if ($childCategories->count())
                                                <ul class="child-list">
                                                    @foreach ($childCategories as $child)
                                                        <li>
                                                            <a href="{{ url('/categories/' . $child->slug) }}">
                                                                <i
                                                                    class="fa-duotone fa-thin fa-circle-dot fa-beat-fade"></i>
                                                                {{ $child->name }}
                                                            </a>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                            @endif
                                        </li>
                                    @endforeach
                                </ul>
                            @else
                                <p>No sub Categories found.</p>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

<div class="cartView">
    <div class="cartHeader">
        <h3>Your Cart</h3>
        <button id="cartClose">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
    <div class="cartBody">
        <p>No products in the cart.</p>
    </div>
    <div class="cartFooter">
        <a href="{{ url('/cart') }}" class="btn btn-primary w-100 mb-2">View Cart</a>
        <a href="{{ url('/checkout') }}" class="btn btn-success w-100">Checkout</a>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Search Here...</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <input type="text" id="searchBox" class="form-control" placeholder="Search...">
                <hr>
                <div id="searchData">
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolorem maiores architecto sapiente
                    assumenda repudiandae tempore autem, quo deleniti, nobis corrupti eius delectus voluptate reiciendis
                    excepturi et atque, illo quia! Placeat.
                </div>
            </div>
        </div>
    </div>
</div>


@if (!session()->has('customer'))
    <div class="modal fade" id="AuthForm" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-content">
                    <div class="modal-body" style="padding: 30px;">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                            style="float: right;margin-top: -10px;"></button>
                        <div class="signIn" style="display: none;">
                            <h1 style="margin-top: -10px;margin-bottom: 13px;">Sign in</h1>

                            <form id="loginForm">
                                @csrf
                                <div class="form-floating mb-3">
                                    <input type="email" class="form-control" id="login_email" name="email" placeholder="Email">
                                    <label for="login_email">Email</label>
                                    <small class="text-danger" id="loginEmailError"></small>
                                </div>

                                <div class="form-floating mb-3">
                                    <input type="password" class="form-control" id="login_password" name="password" placeholder="Password">
                                    <label for="login_password">Password</label>
                                    <small class="text-danger" id="loginPasswordError"></small>
                                </div>

                                <div class="mt-3 mb-3">
                                    <a href="#" style="text-decoration: none;color:rgb(191, 44, 44);font-weight:bold;">Forgot your password?</a>
                                </div>

                                <button type="submit" class="btn btn-primary" style="float: left;width: 100%;">Sign in</button>
                                <br><br>
                                <hr>
                                Don't have an account yet? <span style="cursor:pointer;font-weight:bold" id="showReg">Sign up now</span>
                            </form>
                        </div>

                        <div class="signUp" style="display: block;">
                            <h1 style="margin-top: -10px;margin-bottom: 13px;">Sign up</h1>
                            <form id="registerForm">
                                @csrf
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Name">
                                    <label for="name">Name</label>
                                    <div class="text-danger error-name mt-1"></div>
                                </div>
                                <div class="form-floating mb-3">
                                     <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                                    <label for="email">Email/phone number</label>
                                    <div class="text-danger error-email mt-1"></div>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                    <label for="password">Password</label>
                                    <div class="text-danger error-password mt-1"></div>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password">
                                    <label for="password_confirmation">Confirm Password</label>
                                    <div class="text-danger error-password_confirmation mt-1"></div>
                                </div>
                                <div class="mt-3 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                            value="1" id="flexCheckDefault"
                                            name="terms"
                                            style="border: 1px dotted #000;height: 20px;width: 20px;margin-right: 10px;margin-top: 2px;">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            Yes, I agree with <a href="">Terms &amp; Condition</a></label>
                                    </div>
                                    <div class="text-danger error-terms mt-1"></div>
                                </div>
                                <div class="mt-3 mb-3">
                                    <button class="btn btn-success"
                                        style="float: left;width: 100%;"> Sign up </button>
                                </div>
                                <div id="registerMessage"></div>
                                <div class="mt-3 mb-3">
                                    <br><br>
                                    <hr>
                                    Already have an account? <span style="cursor:pointer;font-weight:bold"
                                        id="showLogin">Sign in now</span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });
    // Register Ajax
    $('#registerForm').on('submit', function(e) {
        e.preventDefault();

        $('.text-danger').html('');
        $('#registerMessage').html('');

        $.ajax({
            url: "{{ route('customer.register.submit') }}",
            type: "POST",
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    window.location.href = "{{ route('customer.dashboard') }}";
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    $.each(errors, function(key, value) {
                        $('.error-' + key).html(value[0]);
                    });
                } else {
                    $('#registerMessage').html('<p class="text-danger">Something went wrong!</p>');
                }
            }
        });
    });

    $('.btn-close[data-bs-dismiss="modal"]').on('click', function(){
        let modal = $(this).closest('.modal');
        modal.find('form').each(function(){
            this.reset();
            $(this).find('.text-danger').html(''); 
        });
        modal.find('#registerMessage, #loginEmailError, #loginPasswordError').html('');
    });

    
    $('.modal').on('hidden.bs.modal', function () {
        $(this).find('form').each(function(){
            this.reset();
            $(this).find('.text-danger').html('');
        });
        $(this).find('#registerMessage, #loginEmailError, #loginPasswordError').html('');
    });

    $('#showLogin').on('click', function(){
        $('#registerForm')[0].reset();
        $('.text-danger').html('');
        $('#registerMessage').html('');
    });



    // Login Ajax
    $('#loginForm').on('submit', function(e){
        e.preventDefault();

        $('#loginEmailError, #loginPasswordError').text('');

        $.ajax({
            url: "{{ route('customer.login.submit') }}",
            type: "POST",
            data: $(this).serialize(),
            success: function(res){
                if(res.success){
                    window.location.href = "{{ route('customer.dashboard') }}";
                }
            },
            error: function(xhr){
                if(xhr.status === 422){
                    let errors = xhr.responseJSON.errors;
                    if(errors.email) $('#loginEmailError').text(errors.email[0]);
                    if(errors.password) $('#loginPasswordError').text(errors.password[0]);
                } else if(xhr.status === 401){
                    $('#loginPasswordError').text(xhr.responseJSON.message);
                } else {
                    $('#loginPasswordError').text('Something went wrong!');
                }
            }
        });
    });
    
</script>
