@php
    $footer = DB::table('footers')->first();
@endphp
<footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="footer-logo mb-3">
                    @if (!empty($footer->logo_image))
                        <img class="img-fluid" src="{{ asset($footer->logo_image) }}" alt="Logo" />

                        @else

                        <img src="" alt="Logo" />

                    @endif
                </div>
                <p class="text-white-50 small">
                    {{ $footer->description ?? 'Your default description here.' }}
                </p>
                <h6 class="text-white mt-4 mb-3">Follow Us</h6>
                <div class="social-icons">

                    @if (!empty($footer->facebook_link))
                        <a href="{{ session('fb') }}" target="_blank">
                            <i class="fa-brands fa-square-facebook"></i>
                        </a>
                    @endif

                    @if (!empty($footer->linkedIn_link))
                        <a href="{{ session('lin') }}" target="_blank">
                            <i class="fa-brands fa-linkedin"></i>
                        </a>
                    @endif

                    @if (!empty($footer->instagram_link))
                        <a href="{{ session('insta') }}" target="_blank">
                            <i class="fa-brands fa-square-instagram"></i>
                        </a>
                    @endif

                    @if (!empty($footer->twitter_link))
                        <a href="{{ session('twit') }}" target="_blank">
                            <i class="fa-brands fa-square-twitter"></i>
                        </a>
                    @endif

                    @if (!empty($footer->youtube_link))
                        <a href="{{ session('yt') }}" target="_blank">
                            <i class="fa-brands fa-square-youtube"></i>
                        </a>
                    @endif

                </div>
            </div>

            <div class="col-md-3 mb-4">
                <h5 class="text-white mb-3">Contact Us</h5>
                <ul class="list-unstyled text-white-50">
                    <li>House #B3, Road # 14,</li>
                    <li>Dhanmondi, Dhaka-1209.</li>
                    <li>Email: support@xyz.com</li>
                </ul>
            </div>

            <div class="col-md-3 mb-4">
                <h5 class="text-white mb-3">Let Us Help You</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white-50 text-decoration-none">Your Account</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none">Your Order</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none">Terms & Conditions</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none">Return & Refund Policy</a></li>
                    <li><a href="#" class="text-white-50 text-decoration-none">FAQ</a></li>
                </ul>
            </div>

            <div class="col-md-3 mb-4">
                <h5 class="text-white mb-3">Get Evaly App</h5>
                <div class="app-badges">
                    <a href="#" class="d-block mb-2">
                        <img src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png"
                            alt="Get it on Google Play" class="img-fluid app-badge"> </a>
                    <a href="#" class="d-block">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Download_on_the_App_Store_RGB_blk.svg/1280px-Download_on_the_App_Store_RGB_blk.svg.png"
                            alt="Download on the App Store" class="img-fluid app-badge"> </a>
                </div>
            </div>

            <hr>

            <div class="col-6 text-start text-white-50 small">
                <p>&copy; 2025 xyz.com Limited. All rights reserved.</p>
            </div>
            <div class="col-6 text-end text-white-50 small">
                <p> Development Partner <a href="https://solveitbd.com/" class="text-decoration-none" target="_blank"
                        style="color:#fbbc04;"><b>Solve IT</b></a> </p>
            </div>
        </div>
    </div>
</footer>
