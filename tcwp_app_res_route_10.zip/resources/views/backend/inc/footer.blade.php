<footer class="content-footer footer bg-footer-theme">
  <div class="container-xxl">
    <div class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
      <div class="mb-2 mb-md-0">
        &#169;
        <script>
          document.write(new Date().getFullYear());
        </script>
        Developed ❤️ by <a href="https://solveitbd.com/" target="_blank" class="footer-link fw-medium">Solve IT</a>
      </div>
      <div class="d-none d-lg-inline-block">

          <a href="https://solveitbd.com/" target="_blank" class="footer-link d-none d-sm-inline-block">Support</a>

      </div>
    </div>
  </div>
</footer>
