<style>
  .menu-sub {
    display: none;
  }

  .menu-item.open > .menu-sub {
    display: block;
  }
</style>
<aside id="layout-menu" class="layout-menu menu-vertical menu" >
  <div class="app-brand demo ">
    <a href="/" class="app-brand-link gap-xl-0 gap-2">
      <span class="app-brand-logo demo me-1">
        <span class="text-primary">
            <img src="{{ asset('lib/img/logo.webp') }}" alt="Logo" style="width: 35px; border-radius: 50px;">
        </span>
    </span>
      <span class="app-brand-text demo menu-text fw-semibold ms-2">Sovle IT</span>
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
      <i class="menu-toggle-icon d-xl-inline-block align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>
    <ul class="menu-inner py-1">

      <!-- Dashboard Header -->
      <li class="menu-header mt-7">
        <span class="menu-header-text" data-i18n="Dashboard">Dashboard</span>
      </li>

      <!-- Dashboard Menu -->
      <li class="menu-item">
        <a href="{{ route('home.index') }}" class="menu-link">
          <i class="menu-icon icon-base ri ri-home-smile-line"></i>
          <div data-i18n="Dashboards">Dashboard</div>
        </a>
      </li>
      <li class="menu-item">
        <a href="{{ route('home.index') }}" class="menu-link">
          <i class="icon-base ri ri-user-3-line icon-22px me-2"></i>
          <div data-i18n="Dashboards">Profile</div>
        </a>
      </li>
      <li class="menu-item">
        <a href="{{ route('home.index') }}" class="menu-link">
          <i class="icon-base ri ri-shopping-bag-line icon-22px me-2"></i>
          <div data-i18n="Dashboards">Orders</div>
        </a>
      </li>
      <li class="menu-item">
        <a href="{{ route('home.index') }}" class="menu-link">
          <i class="icon-base ri ri-map-pin-line icon-22px me-2"></i>
          <div data-i18n="Dashboards">Address</div>
        </a>
      </li>
      <li class="menu-item">
        <a href="{{ route('home.index') }}" class="menu-link">
          <i class="icon-base ri ri-heart-line icon-22px me-2"></i>
          <div data-i18n="Dashboards">Wishlist</div>
        </a>
      </li>
      <li class="menu-item">
        <a href="{{ route('home.index') }}" class="menu-link">
          <i class="icon-base ri ri-delete-bin-line icon-22px me-2"></i>
          <div data-i18n="Dashboards">Delete Account</div>
        </a>
      </li>
    </ul>
</aside>

<div class="menu-mobile-toggler d-xl-none rounded-1">
  <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large text-bg-secondary p-2 rounded-1">
    <i class="ri ri-menu-line icon-base"></i>
    <i class="ri ri-arrow-right-s-line icon-base"></i>
  </a>
</div>
