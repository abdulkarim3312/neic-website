<?php

use UniSharp\LaravelFilemanager\Lfm;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\backend\admin;
use App\Http\Controllers\backend\MenuController;
use App\Http\Controllers\backend\RoleController;
use App\Http\Controllers\backend\UserController;
use App\Http\Controllers\backend\BannerController;
use App\Http\Controllers\backend\ArticleController;
use App\Http\Controllers\backend\ProductController;
use App\Http\Controllers\backend\SettingController;
use App\Http\Controllers\backend\DesignationController;
use App\Http\Controllers\backend\MenuCategoryController;
use App\Http\Controllers\backend\ArticleCategoryController;
use App\Http\Controllers\backend\CommitteeMemberController;
use App\Http\Controllers\backend\AttachmentCategoryController;
use App\Http\Controllers\backend\AttachmentController;

Route::middleware(['check.auth'])->group(function () {
    Route::controller(admin::class)->group(function () {
        Route::get('/admin/login', 'login')->name('admin.login');
        Route::post('/admin/login/processing', 'adminloginCheck')->name('admin.loginCheck');
    });
});



Route::controller(admin::class)->group(function () {
    Route::get('/admin/logout', 'logout')->name('logout');
});


Route::middleware(['check.role:admin,manager,sales'])->group(function () {
   Route::get('/admin', function () {
        return view('backend.dashboard.index');
    });

    Route::prefix('admin')->group(function () {
        Route::get('/dashboard', function () {
            return view('backend.dashboard.index');
        })->name('dashboard');

        Route::resource('roles', RoleController::class);
        Route::resource('users', UserController::class);
        Route::post('/user-status-update/{id}', [UserController::class, 'updateStatus'])->name('user_status_update');
        Route::resource('menu-categories', MenuCategoryController::class);
        Route::post('/category-status-update/{id}', [MenuCategoryController::class, 'updateStatus'])->name('update_status_category');
        Route::resource('menus', MenuController::class);
        Route::post('/menu-status-update/{id}', [MenuController::class, 'updateStatus'])->name('menu_status');

        Route::resource('article-categories', ArticleCategoryController::class);
        Route::post('/article-category-status-update/{id}', [ArticleCategoryController::class, 'updateStatus'])->name('article_category_status');

        Route::resource('articles', ArticleController::class);
        Route::post('/article-status-update/{id}', [ArticleController::class, 'updateStatus'])->name('article_status');

        Route::resource('designations', DesignationController::class);
        Route::post('/designation-status-update/{id}', [DesignationController::class, 'updateStatus'])->name('designation_status');

        Route::resource('committee-members', CommitteeMemberController::class);
        Route::post('/member-status-update/{id}', [CommitteeMemberController::class, 'updateStatus'])->name('member_status');

        Route::resource('attachment-categories', AttachmentCategoryController::class);
        Route::post('/attachment-status-update/{id}', [AttachmentCategoryController::class, 'updateStatus'])->name('attachment_status');

        Route::resource('attachments', AttachmentController::class);
        Route::post('/attachments-status-update/{id}', [AttachmentController::class, 'updateStatus'])->name('attachments_status');
    });
});

Route::group(['prefix' => 'laravel-filemanager', 'middleware' => ['web']], function () {
    Lfm::routes();
});





Route::middleware(['check.role:admin,manager'])->group(function () {
    Route::get('/admin/blank', function () {
        return view('backend.blank');
    });
});
