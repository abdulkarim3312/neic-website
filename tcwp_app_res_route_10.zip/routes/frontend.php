<?php

use App\Http\Middleware\CheckRole;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\frontend\home;

use App\Http\Controllers\frontend\product;
use App\Http\Controllers\frontend\Auth\AuthController;
use App\Http\Controllers\frontend\CustomerDashboardController;

Route::controller(home::class)->group(function () {
    Route::get('/', 'home')->name('home.index');
    Route::get('/searchData', 'searchData')->name('home.searchData');
});


Route::controller(product::class)->group(function () {
    Route::get('/shop', 'shop')->name('shop.view');
    Route::get('/product/{id}', 'productDetails')->name('product.details');
    Route::get('/filterProducts', 'filterProducts')->name('product.filter');
    Route::get('/filterProductPages', 'filterProductPages')->name('product.filterPages');
    Route::get('/filterPageRandomProducts', 'filterPageRandomProducts')->name('product.filterPagesRandom');
    Route::get('/filterPageRandomProductsPagination', 'filterPageRandomProductsPagination')->name('product.filterPageRandomProductsPagination');
    Route::get('/filterProductsByPrice', 'filterProductsByPrice')->name('product.filterProductsByPrice');
});
