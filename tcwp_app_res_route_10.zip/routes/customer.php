<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\frontend\Auth\AuthController;
use App\Http\Controllers\frontend\CustomerDashboardController;

Route::middleware('guest')->group(function () {
    Route::post('/customer/register', [AuthController::class, 'register'])->name('customer.register.submit');
    Route::post('/customer/login', [AuthController::class, 'login'])->name('customer.login.submit');
});

// Protected routes (only logged-in customers)
Route::middleware('customer')->group(function () {
    Route::get('user/dashboard', function () {
        return view('customer.dashboard.index');
    })->name('customer.dashboard');
    Route::get('/customer/order', [CustomerDashboardController::class, 'customerOrder'])->name('customer.order');
    Route::post('/customer/logout', [AuthController::class, 'logout'])->name('customer.logout');
});