<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('committee_member_infos', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('designation_id')->nullable();
            $table->string('article_url')->nullable();
            $table->string('slug')->nullable();
            $table->boolean('is_active')->default(true);
            $table->unsignedBigInteger('entry_by')->nullable();
            $table->timestamp('entry_time')->nullable();
            $table->unsignedBigInteger('last_update_by')->nullable();
            $table->timestamp('last_update_time')->nullable();
            $table->boolean('status')->default(true);
            $table->timestamps();

            $table->foreign('designation_id')
                  ->references('id')->on('designations')
                  ->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('committee_member_infos');
    }
};
