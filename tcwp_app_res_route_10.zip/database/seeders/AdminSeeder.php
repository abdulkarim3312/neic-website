<?php

namespace Database\Seeders;

use App\Models\Admin;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // Define permissions with dot notation
        $permissions = [
            'user'          => ['manage', 'create', 'edit', 'view', 'delete'],
            'role'          => ['create', 'edit', 'view', 'delete'],
            'category'      => ['manage', 'create', 'edit', 'view', 'delete'],
            'subcat'        => ['create', 'edit', 'view', 'delete'],
            'childcat'      => ['create', 'edit', 'view', 'delete'],
            'brand'         => ['create', 'edit', 'view', 'delete'],
            'product'       => ['manage', 'create', 'edit', 'view', 'delete'],
            'attribute'     => ['create', 'edit', 'view', 'delete'],
            'attroption'    => ['create', 'edit', 'view', 'delete'],
            'banner'        => ['manage', 'create', 'edit', 'view', 'delete'],
            'footer'        => ['edit', 'view'],
        ];

        // Create permissions
        foreach ($permissions as $module => $actions) {
            foreach ($actions as $action) {
                Permission::firstOrCreate([
                    'name'       => "{$module}.{$action}", // dot notation
                    'guard_name' => 'admin',
                    'module'     => ucfirst($module),
                ]);
            }
        }

        // Define roles
        $roles = ['admin', 'manager', 'sales'];
        $roleIds = [];

        foreach ($roles as $roleName) {
            $role = Role::firstOrCreate([
                'name'       => $roleName,
                'guard_name' => 'admin',
            ]);
            $roleIds[$roleName] = $role->id;
        }

        // Assign ALL permissions only to admin
        $adminRole = Role::where('name', 'admin')->where('guard_name', 'admin')->first();
        $adminRole->syncPermissions(Permission::where('guard_name', 'admin')->get());

        // Manager & Sales → No permissions assigned (empty)
        $managerRole = Role::where('name', 'manager')->where('guard_name', 'admin')->first();
        $managerRole->syncPermissions([]);

        $salesRole = Role::where('name', 'sales')->where('guard_name', 'admin')->first();
        $salesRole->syncPermissions([]);

        // Create admin users
        $adminUsers = [
            [
                'name'     => 'Admin User',
                'email'    => 'admin@example.com',
                'password' => Hash::make('123456789'),
                'role'     => 'admin',
            ],
            [
                'name'     => 'Manager User',
                'email'    => 'manager@example.com',
                'password' => Hash::make('123456789'),
                'role'     => 'manager',
            ],
            [
                'name'     => 'Sales User',
                'email'    => 'sales@example.com',
                'password' => Hash::make('123456789'),
                'role'     => 'sales',
            ],
        ];

        foreach ($adminUsers as $userData) {
            $admin = Admin::updateOrCreate(
                ['email' => $userData['email']],
                [
                    'name'     => $userData['name'],
                    'password' => $userData['password'],
                    'role_id'  => $roleIds[$userData['role']],
                ]
            );

            $admin->assignRole($userData['role']);
        }
    }
}
