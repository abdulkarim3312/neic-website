<?php

namespace App\Http\Controllers\backend;

use App\Models\Brand;
use App\Models\Product;
use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Support\Str;
use App\Models\ProductImage;
use Illuminate\Http\Request;
use App\Models\ChildCategory;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\Facades\DataTables;


class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if (!in_array('product.view', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        if ($request->ajax()) {
            $products = Product::query();
            return DataTables::of($products)
                ->addColumn('image', function ($row) {
                    return '<img src="' . asset($row->feature_image) . '" width="50">';
                })
                ->addColumn('status', function ($row) {
                    $checked = $row->status == 1 ? 'checked' : '';
                    return '<input type="checkbox" class="status-toggle big-checkbox" data-id="' . $row->id . '" ' . $checked . '>';
                })
                ->addColumn('action', function ($row) {
                    $dropdown = '
                        <div class="dropdown">
                            <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Actions
                            </button>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="dropdown-item" href="' . route('products.show', $row->id) . '">
                                        <i class="fa fa-eye text-primary"></i> View
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="' . route('products.edit', $row->id) . '">
                                        <i class="fa fa-edit text-warning"></i> Edit
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="' . route('products.attributes', $row->id) . '">
                                        <i class="fa fa-list text-info"></i> Attribute
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="' . route('products.attribute_options', $row->id) . '">
                                        <i class="fa fa-sliders text-success"></i> Attribute Option
                                    </a>
                                </li>

                                <!-- Delete -->
                                <li>
                                    <form action="' . route('products.destroy', $row->id) . '" method="POST" class="delete-form" data-id="' . $row->id . '" data-name="' . e($row->name) . '">
                                        ' . csrf_field() . method_field('DELETE') . '
                                        <button type="submit" class="dropdown-item text-danger">
                                            <i class="fa fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </li>

                            </ul>
                        </div>';
                    return $dropdown;
                })
                ->rawColumns(['image', 'status', 'action'])
                ->make(true);
        }
        return view('backend.product.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        if (!in_array('product.create', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $categories = Category::where('status', 1)->get();
        $subCategories = SubCategory::where('status', 1)->get();
        $childCategories = ChildCategory::where('status', 1)->get();
        $brands = Brand::where('status', 1)->get();
        return view('backend.product.create', compact('categories','brands','categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!in_array('product.create', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|numeric',
            'feature_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'images.*' => 'image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        DB::beginTransaction();

        try {
            $featureImagePath = null;

            if ($request->hasFile('feature_image')) {
                $image = $request->file('feature_image');
                $imageName = time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('uploads/feature_images'), $imageName);
                $featureImagePath = 'uploads/feature_images/' . $imageName;
            }

            $product = new Product();
            $product->name = $request->name;
            $product->short_description = $request->short_description;
            $product->description = $request->description;
            $product->product_tag = $request->product_tag;
            $product->meta_keywords = $request->meta_keywords;
            $product->meta_description = $request->meta_description;
            $product->cost_price = $request->cost_price;
            $product->sale_price = $request->sale_price;
            $product->discount_price = $request->discount_price;
            $product->category_id = $request->category_id;
            $product->sub_category_id = $request->sub_category_id;
            $product->child_category_id = $request->child_category_id;
            $product->brand_id = $request->brand_id;
            $product->total_stock = $request->total_stock;
            $product->status = $request->status;
            $product->video_link = $request->video_link;
            $product->feature_image = $featureImagePath;
            $product->save();

            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $image) {
                    $imageName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('uploads/product_galleries'), $imageName);
                    $galleryPath = 'uploads/product_galleries/' . $imageName;

                    $product->galleries()->create([
                        'image' => $galleryPath
                    ]);
                }
            }

            DB::commit();

            return redirect()->route('products.index')->with('success', 'Product created successfully.');

        } catch (\Exception $exception){
            DB::rollBack();
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        if (!in_array('product.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $categories = Category::where('status', 1)->get();
        $brands = Brand::where('status', 1)->get();
        $product = Product::findOrFail($id);
        $subCategories = SubCategory::where('status', 1)
                        ->where('category_id', $product->category_id)
                        ->get();
        $childCategories = ChildCategory::where('status', 1)
                        ->where('subcategory_id', $product->sub_category_id)
                        ->get();
        return view('backend.product.edit', compact('categories','brands','categories','product','subCategories', 'childCategories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!in_array('product.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|numeric',
            'feature_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'images.*' => 'image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        DB::beginTransaction();

        try {
            $product = Product::findOrFail($id);

            if ($request->hasFile('feature_image')) {
                if ($product->feature_image && File::exists(public_path($product->feature_image))) {
                    File::delete(public_path($product->feature_image));
                }

                $image = $request->file('feature_image');
                $imageName = time() . '.' . $image->getClientOriginalExtension();
                $image->move(public_path('uploads/feature_images'), $imageName);
                $product->feature_image = 'uploads/feature_images/' . $imageName;
            }

            $product->name = $request->name;
            $product->short_description = $request->short_description;
            $product->description = $request->description;
            $product->product_tag = $request->product_tag;
            $product->meta_keywords = $request->meta_keywords;
            $product->meta_description = $request->meta_description;
            $product->cost_price = $request->cost_price;
            $product->sale_price = $request->sale_price;
            $product->discount_price = $request->discount_price;
            $product->category_id = $request->category_id;
            $product->sub_category_id = $request->sub_category_id;
            $product->child_category_id = $request->child_category_id;
            $product->brand_id = $request->brand_id;
            $product->total_stock = $request->total_stock;
            $product->status = $request->status;
            $product->video_link = $request->video_link;
            $product->save();

            
            if ($request->has('images')) {
                foreach ($request->file('images') as $id => $newImage) {
                    $gallery = ProductImage::find($id);

                    if ($gallery && $newImage instanceof \Illuminate\Http\UploadedFile) {
                        if (file_exists(public_path($gallery->image))) {
                            unlink(public_path($gallery->image));
                        }

                        $filename = time() . '_' . uniqid() . '.' . $newImage->getClientOriginalExtension();
                        $filepath = 'uploads/product_galleries/' . $filename;
                        $newImage->move(public_path('uploads/product_galleries'), $filename);

                        $gallery->update(['image' => $filepath]);
                    }
                }
            }

            // Handle deletion of removed images
            if ($request->has('remove_image_ids')) {
                foreach ($request->remove_image_ids as $removeId) {
                    $gallery = ProductImage::find($removeId);
                    if ($gallery) {
                        // Delete image file
                        if (file_exists(public_path($gallery->image))) {
                            unlink(public_path($gallery->image));
                        }
                        $gallery->delete();
                    }
                }
            }

            if ($request->hasFile('new_images')) {
                foreach ($request->file('new_images') as $file) {
                    $fileName = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                    $file->move(public_path('uploads/product_galleries'), $fileName);

                    ProductImage::create([
                        'product_id' => $product->id,
                        'image' => 'uploads/product_galleries/' . $fileName,
                    ]);
                }
            }

        

            DB::commit();

            return redirect()->route('products.index')->with('success', 'Product updated successfully.');

        } catch (\Exception $exception){
            DB::rollBack();
            session()->flash('error', $exception->getMessage());
            return redirect()->back();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if (!in_array('product.delete', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        DB::beginTransaction();

        try {
            $product = Product::with('galleries')->findOrFail($id);

            if ($product->feature_image && File::exists(public_path($product->feature_image))) {
                File::delete(public_path($product->feature_image));
            }

            foreach ($product->galleries as $gallery) {
                if ($gallery->image && File::exists(public_path($gallery->image))) {
                    File::delete(public_path($gallery->image));
                }
                $gallery->delete(); 
            }

            $product->delete();

            DB::commit();

            return redirect()->route('products.index')->with('success', 'Product deleted successfully.');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Delete failed: ' . $e->getMessage());
        }
    }

    public function getSubcategories($categoryId)
    {
        $subcategories = SubCategory::where('category_id', $categoryId)
                        ->where('status', 1)
                        ->pluck('name', 'id');
        return response()->json($subcategories);
    }

    public function getChildCategories($subCategoryId)
    {
        $subcategories = ChildCategory::where('subcategory_id', $subCategoryId)->pluck('name', 'id');
        return response()->json($subcategories);
    }

    public function updateStatus(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $product->status = $request->status;
        $product->save();

        return response()->json(['message' => 'Status updated successfully']);
    }
}
