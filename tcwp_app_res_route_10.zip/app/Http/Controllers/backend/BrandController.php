<?php

namespace App\Http\Controllers\backend;

use App\Models\Brand;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\Facades\DataTables;

class BrandController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if (!in_array('brand.view', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        if ($request->ajax()) {
            $brands = Brand::query();
            return DataTables::of($brands)
                ->addColumn('image', function ($row) {
                    $imageUrl = $row->image ? asset($row->image) : asset('default.png');
                    return '<img src="' . $imageUrl . '" width="50">';
                })
                ->addColumn('status', function ($row) {
                    $checked = $row->status ? 'checked' : '';
                    return '<input type="checkbox" class="status-toggle big-checkbox" data-id="' . $row->id . '" ' . $checked . '>';
                })
                ->addColumn('action', function ($row) {
                    $edit = '<button type="button" class="btn btn-sm btn-primary text-white edit_btn editBtn mx-1" data-id="' . $row->id . '">
                            <i class="fa fa-edit"></i>
                        </button>';
                    $delete = '<form action="' . route('brands.destroy', $row->id) . '" method="POST" class="delete-form d-inline" data-id="' . $row->id . '" data-name="' . $row->name . '">' .
                        csrf_field() .
                        method_field('DELETE') .
                        '<button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>' .
                        '</form>';
                    return $edit . $delete;
                })
                ->rawColumns(['image', 'status', 'action'])
                ->make(true);
        }
        return view('backend.brand.index');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        if (!in_array('brand.create', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $request->merge([
            'name' => preg_replace('/\s+/', ' ', trim($request->input('name')))
        ]);
        $request->validate([
            'name' => 'required|string|max:255|unique:brands,name',
            'description' => 'nullable|string',
            'website' => 'nullable|string|max:255',
            'status' => 'required|boolean',
            'image' => 'nullable|image|max:2048',
        ]);

        $brand = new Brand();
        $brand->name = $request->name;
        $brand->slug = Str::slug($request->name) . '-' . Str::lower(Str::random(6));
        $brand->description = $request->description;
        $brand->website = $request->website;
        $brand->status = $request->status;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/brand_image'), $imageName);
            $brand->image = 'uploads/brand_image/' . $imageName;
        }

        $brand->save();
        return response()->json(['success' => true, 'message' => 'created successfully!']);

    }

    public function edit(Brand $brand)
    {
        if (!in_array('brand.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        return response()->json($brand);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!in_array('brand.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $request->merge([
            'name' => preg_replace('/\s+/', ' ', trim($request->input('name')))
        ]);

        $request->validate([
            'name' => 'required|string|max:255|unique:brands,name,' . $id,
            'description' => 'nullable|string',
            'website' => 'nullable|string|max:255',
            'status' => 'required|boolean',
            'image' => 'nullable|image|max:2048',
        ]);

        $brand = Brand::findOrFail($id);
        $brand->name = $request->name;
        $brand->slug = Str::slug($request->name) . '-' . Str::lower(Str::random(6));
        $brand->description = $request->description;
        $brand->website = $request->website;
        $brand->status = $request->status;

        if ($request->hasFile('image')) {
            if ($brand->image && file_exists(public_path($brand->image))) {
                @unlink(public_path($brand->image));
            }

            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/brand_image'), $imageName);
            $brand->image = 'uploads/brand_image/' . $imageName;
        }

        $brand->save();

        return response()->json([
            'success' => true,
            'message' => 'Brand updated successfully!'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Brand $brand)
    {
        if (!in_array('brand.delete', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        if ($brand->image && File::exists(public_path($brand->image))) {
            File::delete(public_path($brand->image));
        }
        $brand->delete();

        return response()->json(['success' => true, 'message' => 'Deleted successfully!']);
    }

    public function updateStatus(Request $request, $id)
    {
        $brand = Brand::findOrFail($id);
        $brand->status = $request->status;
        $brand->save();

        return response()->json(['message' => 'Status updated successfully']);
    }
}
