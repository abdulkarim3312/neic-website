<?php

namespace App\Http\Controllers\backend;

use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\Facades\DataTables;

class SubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if (!in_array('subcat.view', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        if ($request->ajax()) {
            $subCategories = SubCategory::with('category');

            return DataTables::of($subCategories)
                ->addColumn('category', function ($row) {
                    return $row->category->name ?? '';
                })
                ->addColumn('status', function ($row) {
                    $checked = $row->status ? 'checked' : '';
                    return '<input type="checkbox" class="status-toggle big-checkbox" data-id="' . $row->id . '" ' . $checked . '>';
                })
                ->addColumn('action', function ($row) {
                    $edit = '<button type="button" class="btn btn-sm btn-primary text-white editBtn mx-1" data-id="' . $row->id . '"><i class="fa fa-edit"></i></button>';

                    $delete = '<form action="' . route('sub-categories.destroy', $row->id) . '" method="POST" class="delete-form d-inline" data-id="' . $row->id . '" data-name="' . $row->name . '">' .
                        csrf_field() .
                        method_field('DELETE') .
                        '<button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>' .
                        '</form>';

                    return $edit . $delete;
                })
                ->rawColumns(['status', 'action']) // Ensure HTML rendering
                ->make(true);
        }
        $categories = Category::where('status', 1)->get();
        return view('backend.sub_category.index', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->merge([
            'name' => preg_replace('/\s+/', ' ', trim($request->input('name')))
        ]);
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'name' => 'required|string|max:255|unique:sub_categories,name',
            'meta_keywords' => 'nullable|string|max:255',
            'status' => 'required|boolean',
        ]);

        DB::beginTransaction();

        try {
            $subCategory = new SubCategory();
            $subCategory->category_id = $request->category_id;
            $subCategory->name = $request->name;
            $subCategory->slug = Str::slug($request->name) . '-' . Str::lower(Str::random(6));
            $subCategory->meta_keywords = $request->meta_keywords;
            $subCategory->status = $request->status;
            $subCategory->save();

            DB::commit();

            return response()->json(['success' => true, 'message' => 'created successfully!']);

        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to update SubCategory: ' . $exception->getMessage()
            ], 500);
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SubCategory $subCategory)
    {
        if (!in_array('subcat.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        return response()->json($subCategory);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!in_array('subcat.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $request->merge([
            'name' => preg_replace('/\s+/', ' ', trim($request->input('name')))
        ]);

        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'name' => 'required|string|max:255|unique:sub_categories,name,' . $id,
            'meta_keywords' => 'nullable|string|max:255',
            'status' => 'required|boolean',
        ]);

        DB::beginTransaction();

        try {
            $subCategory = SubCategory::findOrFail($id);

            $subCategory->category_id = $request->category_id;
            $subCategory->name = $request->name;
            $subCategory->slug = Str::slug($request->name) . '-' . Str::lower(Str::random(6));
            $subCategory->meta_keywords = $request->meta_keywords;
            $subCategory->status = $request->status;
            $subCategory->save();

            DB::commit();

            return response()->json(['success' => true, 'message' => 'Updated successfully!']);

        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to update SubCategory: ' . $exception->getMessage()
            ], 500);
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SubCategory $subCategory)
    {
        if (!in_array('subcat.delete', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $subCategory->delete();
        return response()->json(['success' => true, 'message' => 'Deleted successfully!']);
    }

    public function updateStatus(Request $request, $id)
    {
        $subCategory = SubCategory::findOrFail($id);
        $subCategory->status = $request->status;
        $subCategory->save();

        return response()->json(['message' => 'Status updated successfully']);
    }
}
