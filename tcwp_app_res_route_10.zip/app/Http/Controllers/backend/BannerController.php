<?php

namespace App\Http\Controllers\backend;

use App\Models\Banner;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\File;

class BannerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $brands = Banner::query();
            return DataTables::of($brands)
                ->addColumn('image', function ($row) {
                    $imageUrl = $row->image ? asset($row->image) : asset('default.png');
                    return '<img src="' . $imageUrl . '" width="50">';
                })
                ->addColumn('status', function ($row) {
                    $checked = $row->status ? 'checked' : '';
                    return '<input type="checkbox" class="status-toggle big-checkbox" data-id="' . $row->id . '" ' . $checked . '>';
                })
                ->addColumn('action', function ($row) {
                    $edit = '<button type="button" class="btn btn-sm btn-primary text-white edit_btn editBtn mx-1" data-id="' . $row->id . '">
                            <i class="fa fa-edit"></i>
                        </button>';
                    $delete = '<form action="' . route('brands.destroy', $row->id) . '" method="POST" class="delete-form d-inline" data-id="' . $row->id . '" data-name="' . $row->name . '">' .
                        csrf_field() .
                        method_field('DELETE') .
                        '<button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>' .
                        '</form>';
                    return $edit . $delete;
                })
                ->rawColumns(['image', 'status', 'action'])
                ->make(true);
        }
        return view('backend.banner.index');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->merge([
            'title' => preg_replace('/\s+/', ' ', trim($request->input('title')))
        ]);
        $request->validate([
            'title' => 'required|string|max:255|unique:banners,title',
            'status' => 'required|boolean',
            'image' => 'nullable|image|max:2048',
        ]);

        $banner = new Banner();
        $banner->title = $request->title;
        $banner->status = $request->status;

        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/banner_image'), $imageName);
            $banner->image = 'uploads/banner_image/' . $imageName;
        }

        $banner->save();
        return response()->json(['success' => true, 'message' => 'created successfully!']);

    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Banner $banner)
    {
        return response()->json($banner);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->merge([
            'title' => preg_replace('/\s+/', ' ', trim($request->input('title')))
        ]);

        $request->validate([
            'title' => 'required|string|max:255|unique:banners,title,' . $id,
            'status' => 'required|boolean',
            'image' => 'nullable|image|max:2048',
        ]);

        $banner = Banner::findOrFail($id);
        $banner->title = $request->title;
        $banner->status = $request->status;

        if ($request->hasFile('image')) {
            if ($banner->image && file_exists(public_path($banner->image))) {
                unlink(public_path($banner->image));
            }

            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/banner_image'), $imageName);
            $banner->image = 'uploads/banner_image/' . $imageName;
        }

        $banner->save();

        return response()->json(['success' => true, 'message' => 'Updated successfully!']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Banner $banner)
    {
        if ($banner->image && File::exists(public_path($banner->image))) {
            File::delete(public_path($banner->image));
        }
        $banner->delete();

        return response()->json(['success' => true, 'message' => 'Deleted successfully!']);
    }

    public function updateStatus(Request $request, $id)
    {
        $banner = Banner::findOrFail($id);
        $banner->status = $request->status;
        $banner->save();

        return response()->json(['message' => 'Status updated successfully']);
    }
}
