<?php

namespace App\Http\Controllers\backend;

use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\ChildCategory;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Yajra\DataTables\Facades\DataTables;

class ChildCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        if (!in_array('childcat.view', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        if ($request->ajax()) {
            $childCategories = ChildCategory::with('category', 'subcategory');

            return DataTables::of($childCategories)
                ->addColumn('category', function ($row) {
                    return $row->category->name ?? '';
                })
                ->addColumn('subcategory', function ($row) {
                    return $row->subcategory->name ?? '';
                })
                ->addColumn('status', function ($row) {
                    $checked = $row->status ? 'checked' : '';
                    return '<input type="checkbox" class="status-toggle big-checkbox" data-id="' . $row->id . '" ' . $checked . '>';
                })
                ->addColumn('action', function ($row) {
                    $edit = '<button type="button" class="btn btn-sm btn-primary text-white editBtn mx-1" data-id="' . $row->id . '"><i class="fa fa-edit"></i></button>';

                    $delete = '<form action="' . route('child-categories.destroy', $row->id) . '" method="POST" class="delete-form d-inline" data-id="' . $row->id . '" data-name="' . $row->name . '">' .
                        csrf_field() .
                        method_field('DELETE') .
                        '<button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>' .
                        '</form>';

                    return $edit . $delete;
                })
                ->rawColumns(['status', 'action']) 
                ->make(true);
        }

        $categories = Category::where('status', 1)->get();
        $subCategories = SubCategory::where('status', 1)->latest()->get();
        
        return view('backend.child_category.index', compact('subCategories', 'categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->merge([
            'name' => preg_replace('/\s+/', ' ', trim($request->input('name')))
        ]);
        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:sub_categories,id',
            'name' => 'required|string|max:255|unique:child_categories,name',
            'status' => 'required|boolean',
        ]);

        DB::beginTransaction();

        try {
            $childCategory = new ChildCategory();
            $childCategory->category_id = $request->category_id;
            $childCategory->subcategory_id = $request->subcategory_id;
            $childCategory->name = $request->name;
            $childCategory->slug = Str::slug($request->name) . '-' . Str::lower(Str::random(6));
            $childCategory->status = $request->status;
            $childCategory->save();

            DB::commit();

            return response()->json(['success' => true, 'message' => 'created successfully!']);

        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to update ChildCategory: ' . $exception->getMessage()
            ], 500);
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ChildCategory $childCategory)
    {
        if (!in_array('childcat.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        return response()->json($childCategory);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        if (!in_array('childcat.edit', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $request->merge([
            'name' => preg_replace('/\s+/', ' ', trim($request->input('name')))
        ]);

        $request->validate([
            'category_id' => 'required|exists:categories,id',
            'subcategory_id' => 'required|exists:sub_categories,id',
            'name' => 'required|string|max:255|unique:child_categories,name,' . $id,
            'status' => 'required|boolean',
        ]);

        DB::beginTransaction();

        try {
            $childCategory = ChildCategory::findOrFail($id);
            $childCategory->category_id = $request->category_id;
            $childCategory->subcategory_id = $request->subcategory_id;
            $childCategory->name = $request->name;
            $childCategory->slug = Str::slug($request->name) . '-' . Str::lower(Str::random(6));
            $childCategory->status = $request->status;
            $childCategory->save();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'ChildCategory updated successfully!'
            ]);

        } catch (\Exception $exception) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Failed to update ChildCategory: ' . $exception->getMessage()
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ChildCategory $childCategory)
    {
        if (!in_array('childcat.delete', session('permissions', []))) {
            abort(403, 'Access denied');
        }
        $childCategory->delete();
        return response()->json(['success' => true, 'message' => 'Category deleted successfully!']);
    }

    public function updateStatus(Request $request, $id)
    {
        $childCategory = ChildCategory::findOrFail($id);
        $childCategory->status = $request->status;
        $childCategory->save();

        return response()->json(['message' => 'Status updated successfully']);
    }
}
