<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Footer;
use Illuminate\Http\Request;
use DB;

class SettingController extends Controller
{

    public function footerPage()
    {
        $footer = Footer::first();
        return view('backend.setting.footer.create', compact('footer'));
    }

    public function footerCreateOrUpdate(Request $request)
    {

        $logoImagePath = null;
        if ($request->hasFile('logo_image')) {
            $logo = $request->file('logo_image');
            $imageName = time() . '.' . $logo->getClientOriginalExtension();
            $logo->move(public_path('uploads/site_logo'), $imageName);
            $logoImagePath = 'uploads/site_logo/' . $imageName;
        }
        $check = Footer::first();
        $data = [
            'description' => $request->description,
            'facebook_link' => $request->facebook_link,
            'linkedIn_link' => $request->linkedIn_link,
            'instagram_link' => $request->instagram_link,
            'twitter_link' => $request->twitter_link,
            'youtube_link' => $request->youtube_link,
        ];

        if ($logoImagePath) {
            $data['logo_image'] = $logoImagePath;
        }

        if ($check) {
            if ($logoImagePath && $check->logo_image && file_exists(public_path($check->logo_image))) {
                unlink(public_path($check->logo_image));
            }
            $check->update($data);
        } else {
            Footer::create($data);
        }


        return redirect()->back()->with('success', 'Updated Successfully!');
    }

}
