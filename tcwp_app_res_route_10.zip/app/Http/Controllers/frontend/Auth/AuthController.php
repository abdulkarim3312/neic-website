<?php

namespace App\Http\Controllers\frontend\Auth;

use Pest\Support\Str;
use App\Models\Customer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|email|unique:customers,email',
            'password' => 'required|string|min:6|confirmed', 
            'terms'    => 'accepted',
        ]);

        $customer = Customer::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'password' => Hash::make($request->password),
            'terms_accepted'  => $request->has('terms'),
        ]);

        $request->session()->put('customer', [
            'id'    => $customer->id,
            'name'  => $customer->name,
            'email' => $customer->email,
        ]);

        return response()->json(['success' => true]);
    }


    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        $customer = Customer::where('email', $request->email)->first();

        if (!$customer) {
            return response()->json(['success' => false, 'message' => 'Email not found'], 401);
        }

        if (!Hash::check($request->password, $customer->password)) {
            return response()->json(['success' => false, 'message' => 'Password is incorrect'], 401);
        }

        $request->session()->put('customer', [
            'id'    => $customer->id,
            'name'  => $customer->name,
            'email' => $customer->email,
        ]);

        return response()->json(['success' => true]);
    }

    public function logout(Request $request)
    {
        $request->session()->forget('customer');
        return redirect()->route('home.index');
    }

    public function showLinkRequestForm()
    {
        return view('frontend.auth.passwords.email');
    }

    public function sendResetLinkEmail(Request $request)
    {
        $request->validate(['email' => 'required|email']);

        $status = Password::broker('customers')->sendResetLink(
            $request->only('email')
        );

        return $status === Password::RESET_LINK_SENT
                    ? back()->with(['status' => __($status)])
                    : back()->withErrors(['email' => __($status)]);
    }


    public function showResetForm(Request $request, $token = null)
    {
        return view('frontend.auth.passwords.reset', [
            'token' => $token,
            'email' => $request->email,
        ]);
    }

    public function reset(Request $request)
    {
        $request->validate([
            'token'    => 'required',
            'email'    => 'required|email',
            'password' => 'required|string|min:6|confirmed',
        ]);

        $status = Password::broker('customers')->reset(
            $request->only('email', 'password', 'password_confirmation', 'token'),
            function ($customer, $password) {
                $customer->password = Hash::make($password);
                $customer->setRememberToken(Str::random(60));
                $customer->save();

                Auth::guard('customer')->login($customer);
            }
        );

        return $status === Password::PASSWORD_RESET
                    ? redirect()->route('customer.dashboard')->with('status', __($status))
                    : back()->withErrors(['email' => [__($status)]]);
    }
}
