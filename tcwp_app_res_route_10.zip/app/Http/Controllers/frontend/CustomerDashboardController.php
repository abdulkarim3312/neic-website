<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomerDashboardController extends Controller
{
    public function dashboard()
    {
        return view('customer.dashboard.index');
    }

    public function customerOrder()
    {
        return view('customer.dashboard.index');
    }
}
