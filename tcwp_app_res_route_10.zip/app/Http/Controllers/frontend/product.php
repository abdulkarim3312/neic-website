<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class product extends Controller
{

    public function shop(){
        $products = DB::table('products')->get();
        // Filter products that are active
        $categories = DB::table('categories')->get();
        $subcategories = DB::table('sub_categories')->get();
        $childcategories = DB::table('child_categories')->get();

        return view('frontend.shop.shop', compact('products' , 'categories','subcategories','childcategories'));
    }


    public function filterProducts(Request $req){

           $take = 20;

        if($req->type == 'category'){

            $productCount = DB::table('products')
                ->where('category_id', $req->id)
                ->where('status', true)
                ->count('id');


            $products = DB::table('products')
                ->where('category_id', $req->id)
                ->where('status', true)
                ->skip(0)->take($take)->get();

        }

        if($req->type == 'subCategory'){
            $productCount = DB::table('products')
                ->where('sub_category_id', $req->id)
                ->where('status', true)
                ->count('id');

            $products = DB::table('products')
                ->where('sub_category_id', $req->id)
                ->where('status', true)
                ->skip(0)->take($take)->get();

        }
        if($req->type == 'childCategory'){
            $productCount = DB::table('products')
                ->where('child_category_id', $req->id)
                ->where('status', true)
                ->count('id');


            $products = DB::table('products')
                ->where('child_category_id', $req->id)
                ->where('status', true)
                ->skip(0)->take($take)->get();
        }


        return view('frontend.shop.filterProducts', compact('products', 'productCount'));
    }


    public function filterProductPages(Request $req){
        $take = 20;
        $currentPage = $req->page - 1;
        $skip = $currentPage * $take;

        if($req->type == 'category'){
            $products = DB::table('products')
                ->where('category_id', $req->id)
                ->where('status', true)
                ->skip($skip)->take($take)->get();
        }

        if($req->type == 'subCategory'){
            $products = DB::table('products')
                ->where('sub_category_id', $req->id)
                ->where('status', true)
                ->skip($skip)->take($take)->get();
        }
        if($req->type == 'childCategory'){
            $products = DB::table('products')
                ->where('child_category_id', $req->id)
                ->where('status', true)
                ->skip($skip)->take($take)->get();
        }


        return view('frontend.shop.filterProductPage', compact('products'));


    }

    public function filterPageRandomProducts(Request $req){
        $take = 20;
        $productCount = DB::table('products')
                ->where('status', true)
                ->count('id');

         $products = DB::table('products')
                ->where('status', true)
                ->take($take)
                ->get();

        return view('frontend.shop.filterRandomProduct', compact('products', 'productCount'));
    }


    public function filterPageRandomProductsPagination(Request $req){
        $take = 20;
        $currentPage = $req->page - 1;
        $skip = $currentPage * $take;

        $products = DB::table('products')
                ->where('status', true)
                ->skip($skip)->take($take)
                ->get();

        return view('frontend.shop.filterRandomProductPage', compact('products'));
    }


    public function filterProductsByPrice(Request $req){
        $take = 20;
        $currentPage = $req->page - 1;
        $skip = $currentPage * $take;

        $minPrice = $req->minPrice;
        $maxPrice = $req->maxPrice;

        $productCount = DB::table('products')
            ->where('status', true)
            ->whereBetween('sale_price', [$minPrice, $maxPrice])
            ->skip($skip)->take($take)
            ->count('id');

        $products = DB::table('products')
            ->where('status', true)
            ->whereBetween('sale_price', [$minPrice, $maxPrice])
            ->skip($skip)->take($take)
            ->get();

        return view('frontend.shop.filterProductsByPrice', compact('products' , 'productCount'));
    }





    public function productDetails($id){

        $pdt = DB::table('products')->where('slug' , $id)->first();
        $pdtImg = DB::table('product_images')->where('product_id' , $pdt->id)->get();

         $relatedProducts = DB::table('products')
        ->where('status', true)
        ->where('id', '!=', $id) // এই product টা বাদ দাও
        ->where('category_id', $pdt->category_id) // একই ক্যাটাগরির
        ->orderBy('created_at', 'desc')
        ->limit(5)
        ->get();



        return view ('frontend.products.details' , compact('pdt' , 'pdtImg' , 'relatedProducts'));

    }
}
