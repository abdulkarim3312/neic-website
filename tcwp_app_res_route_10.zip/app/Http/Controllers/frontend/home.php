<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class home extends Controller
{
    public function home()
    {

        $banners = DB::table('banners')->where('status', 1)->get();

        $categories = DB::table('categories')->where('status', 1)
                ->inRandomOrder()->get();


        $latestProducts = DB::table('products')
        ->where('status', true)
        ->orderBy('created_at', 'desc')
        ->limit(5)
        ->get();

        $pdt_subcat = DB::table('sub_categories')
            ->select('id', 'name')
            ->where('status', true)
            ->inRandomOrder()
            ->get();

        foreach ($pdt_subcat as $subcat) {
            $subcat->products = DB::table('products')
                ->where('sub_category_id', $subcat->id)
                ->where('status', true)
                ->inRandomOrder()
                ->limit(10)
                ->get();
        }


        return view('frontend.home.index' , compact('banners' , 'categories' , 'latestProducts' , 'pdt_subcat'));
    }


    public function searchData(Request $req) {

            $results = DB::table('products')
            ->select('id', 'name' , 'feature_image' , )
            ->where('name', 'LIKE', "%{$req->keyVal}%")
            ->orWhere('description', 'LIKE', "%{$req->keyVal}%")
            ->orWhere('product_tag', 'LIKE', "%{$req->keyVal}%")
            ->get();


            return view('frontend.home.searchData' , compact('results'));


    }




}
