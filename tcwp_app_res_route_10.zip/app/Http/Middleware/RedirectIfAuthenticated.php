<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;

class RedirectIfAuthenticated
{
    public function handle($request, Closure $next)
    {
        // যদি ইউজার লগইনড থাকে (session এ user_id থাকে), login পেজে ঢুকতে দেবে না
        if (Session::has('role')) {
            return redirect('/admin/dashboard'); // বা যেখানেই পাঠাতে চাও
        }

        return $next($request);
    }
}
