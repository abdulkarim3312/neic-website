<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str; 

class Product extends Model
{
    protected $guarded = [];

    public function galleries() { 
        return $this->hasMany(ProductImage::class); 
    }
    public function category() { 
        return $this->belongsTo(Category::class); 
    }

    public static function boot()
    {
        parent::boot();

        static::creating(function ($product) {
            if (empty($product->sku)) {
                $product->sku = self::generateAdvancedSku($product);
            }

            if (empty($product->slug)) {
                $product->slug = self::generateSlug($product->name);
            }
        });

        static::updating(function ($product) {
            if ($product->isDirty('name')) {
                $product->slug = self::generateSlug($product->name);
            }
        });
    }

    public static function generateAdvancedSku($product)
    {
        $categoryCode = strtoupper(substr($product->category->name ?? 'GEN', 0, 3)); 
        $datePart     = now()->format('ym'); 
        $randomPart   = strtoupper(Str::random(6)); 

        return "{$categoryCode}-{$datePart}-{$randomPart}";
    }

    public static function generateSlug($name)
    {
        $baseSlug = Str::slug($name);

        do {
            $slug = "{$baseSlug}-" . Str::lower(Str::random(3));
        } while (Product::where('slug', $slug)->exists());

        return $slug;
    }
}
