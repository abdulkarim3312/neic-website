<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PublicOpenion extends Model
{
    use HasFactory;

    protected $table = 'public_openions';

    protected $guarded = [];

    protected $casts = [
        'entry_time' => 'datetime',
    ];
}
